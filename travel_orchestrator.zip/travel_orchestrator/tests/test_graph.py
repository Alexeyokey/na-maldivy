"""Граф LangGraph ведёт себя так же, как обычный цикл."""

from datetime import date

import pytest

pytest.importorskip("langgraph")

from orchestrator.graph import build_turn_graph, run_turn_with_graph  # noqa: E402
from orchestrator.offline_llm import OfflineLLM  # noqa: E402
from orchestrator.orchestrator import TravelOrchestrator  # noqa: E402
from orchestrator.router import Action  # noqa: E402
from orchestrator.schemas import Stage  # noqa: E402


def test_graph_dialog():
    orch = TravelOrchestrator(llm=OfflineLLM(), today=lambda: date(2026, 10, 25))
    graph = build_turn_graph(orch)

    r1 = run_turn_with_graph(orch, "Хочу на тёплое море в ноябре на неделю вдвоём", graph)
    assert r1.action == Action.ASK_CLARIFICATION

    r2 = run_turn_with_graph(orch, "Из Москвы", graph)
    assert r2.action == Action.SEARCH
    assert orch.state.stage == Stage.RESULTS_SHOWN
    assert len(orch.history) == 4
