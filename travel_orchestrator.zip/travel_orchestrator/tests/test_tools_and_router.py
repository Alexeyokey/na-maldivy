"""Тема 2 (инструменты) и Тема 3 (роутер)."""

import json

from orchestrator.router import Action, decide
from orchestrator.schemas import MessageAnalysis, Stage, TripRequirements, TripState
from orchestrator.tools import SearchDestinationsArgs, default_registry, search_destinations

BASE_ARGS = dict(
    departure_city="Москва", month=11, duration_days=7, travelers=2,
    interests=["sea", "nature"], budget_total=120000, max_flight_hours=6,
    weather_preference="warm", hotel_size="small_or_medium",
)


# --- search_destinations -----------------------------------------------------

def test_search_example_from_plan():
    payload = search_destinations(SearchDestinationsArgs(**BASE_ARGS))
    ids = [r["id"] for r in payload["results"]]
    # Хургада укладывается в бюджет и стоит первой; Шарм дороже, но подходит по интересам.
    assert ids[0] == "hurghada"
    assert payload["results"][0]["fits_budget"] is True
    assert payload["results"][0]["total_rub"] == 2 * (28000 + 4500 * 7)
    assert "sharm" in ids
    # Пхукет отсеян по времени перелёта, Анталья — по погоде/сезону.
    assert "phuket" not in ids and "antalya" not in ids


def test_over_budget_options_are_marked_not_dropped():
    payload = search_destinations(SearchDestinationsArgs(**{**BASE_ARGS, "budget_total": 50000}))
    assert payload["results"]
    assert all(not r["fits_budget"] for r in payload["results"])
    assert "дороже бюджета" in payload["message"]


def test_nothing_found_explains_why():
    payload = search_destinations(SearchDestinationsArgs(**{**BASE_ARGS, "max_flight_hours": 1}))
    assert payload["results"] == []
    assert "перелёт дольше допустимого" in payload["message"]


def test_registry_rejects_bad_arguments():
    registry = default_registry()
    result = registry.execute("search_destinations", {**BASE_ARGS, "month": 15})
    assert not result.ok and "month" in result.payload["error"]


def test_registry_rejects_unknown_city():
    result = default_registry().execute("search_destinations", {**BASE_ARGS, "departure_city": "Марс"})
    assert not result.ok and "неизвестный город" in result.payload["error"]


def test_registry_rejects_unknown_tool_and_broken_json():
    registry = default_registry()
    assert not registry.execute("buy_tickets", {}).ok
    assert not registry.execute("search_destinations", "{не json").ok


def test_registry_accepts_json_string_with_nulls():
    args = {**BASE_ARGS, "budget_total": None, "destination": None, "limit": 3}
    result = default_registry().execute("search_destinations", json.dumps(args))
    assert result.ok and len(result.payload["results"]) <= 3


def test_openai_spec_is_strict():
    spec = default_registry().openai_specs()[0]["function"]
    assert spec["strict"] is True
    params = spec["parameters"]
    assert set(params["required"]) == set(params["properties"])
    assert params["additionalProperties"] is False


# --- router ------------------------------------------------------------------

def full_state(**kwargs) -> TripState:
    return TripState(requirements=TripRequirements(
        departure_city="Москва", month=11, duration_days=7, travelers=2), **kwargs)


def test_router_asks_first_missing_field():
    decision = decide(TripState(), MessageAnalysis.empty("search"))
    assert decision.action == Action.ASK_CLARIFICATION
    assert decision.missing_field == "departure_city"


def test_router_searches_when_enough_data():
    assert decide(full_state(), MessageAnalysis.empty("search")).action == Action.SEARCH


def test_router_researches_when_stale():
    state = full_state(search_results=[{"id": "x"}], results_stale=True)
    assert decide(state, MessageAnalysis.empty("modify_trip")).action == Action.SEARCH


def test_router_explains_question_about_results():
    state = full_state(search_results=[{"id": "x"}], stage=Stage.RESULTS_SHOWN)
    assert decide(state, MessageAnalysis.empty("general_question")).action == Action.EXPLAIN


def test_router_never_books_without_confirmation_stage():
    state = full_state(search_results=[{"id": "x"}, {"id": "y"}], stage=Stage.RESULTS_SHOWN)
    analysis = MessageAnalysis.empty("confirm")
    assert decide(state, analysis).action == Action.ASK_WHICH_OPTION

    analysis.selected_option_id = "y"
    decision = decide(state, analysis)
    assert decision.action == Action.REQUEST_CONFIRMATION and decision.option_id == "y"


def test_router_books_only_after_confirmation():
    state = full_state(search_results=[{"id": "x"}], selected_option_id="x",
                       stage=Stage.AWAITING_CONFIRMATION)
    assert decide(state, MessageAnalysis.empty("confirm")).action == Action.BOOK
    assert decide(state, MessageAnalysis.empty("other")).action == Action.CANCEL_CONFIRMATION


def test_router_ignores_hallucinated_option_id():
    state = full_state(search_results=[{"id": "x"}, {"id": "y"}], stage=Stage.RESULTS_SHOWN)
    analysis = MessageAnalysis.empty("confirm")
    analysis.selected_option_id = "atlantis"
    assert decide(state, analysis).action == Action.ASK_WHICH_OPTION
