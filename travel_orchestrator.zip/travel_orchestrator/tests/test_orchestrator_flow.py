"""
Сквозные тесты цикла оркестратора на OfflineLLM (без сети).

Плюс «вредные» заглушки, которые проверяют, что код страхует модель:
модель подменяет аргументы, не вызывает инструмент, падает.
"""

import json
from datetime import date

import pytest

from orchestrator.llm_client import AssistantTurn, LLMError, ToolCall
from orchestrator.offline_llm import OfflineLLM, analyze_text
from orchestrator.orchestrator import TravelOrchestrator
from orchestrator.router import Action
from orchestrator.schemas import Stage

PLAN_MESSAGE = ("Хочу на тёплое море в ноябре, на неделю, с девушкой. На двоих не больше 120 тысяч, "
                "перелёт не дольше 6 часов. Любим природу и не хотим отдыхать в огромном отеле.")


def make_orch(llm=None) -> TravelOrchestrator:
    return TravelOrchestrator(llm=llm or OfflineLLM(), today=lambda: date(2026, 10, 25))


# --- 10 сообщений из Этапа 3 плана -------------------------------------------

@pytest.mark.parametrize("text, expected_intent, expected_patch", [
    # 1. полностью определённый запрос
    ("Из Москвы в Хургаду в ноябре на 7 дней, 2 человека, бюджет 150 тысяч", "search",
     {"departure_city": "Москва", "destination": "Хургада", "month": 11, "duration_days": 7,
      "travelers": 2, "budget_total": 150000}),
    # 2. без бюджета
    ("Хочу на море в ноябре на неделю вдвоём", "search",
     {"month": 11, "duration_days": 7, "travelers": 2}),
    # 3. без дат
    ("Бюджет 100 тысяч на двоих, хотим к морю", "search", {"budget_total": 100000, "travelers": 2}),
    # 4. несколько предпочтений — проверяются интересами ниже
    ("Любим природу, горы и местную кухню, без пляжей", "search", {}),
    # 5. исправление бюджета (в состоянии уже есть бюджет — см. тест ниже)
    # 6. противоречивые требования
    ("Хочу дёшево, но в пятизвёздочный люкс на Мальдивах", "search", {"destination": "Мальдивы"}),
    # 7. без конкретного направления
    ("Куда поехать в ноябре погреться?", "inspiration", {"month": 11, "weather_preference": "warm"}),
    # 8. очень короткий запрос
    ("на море", "search", {}),
    # 9. несколько путешественников
    ("Нас 4 человека, летим из Питера на 10 дней", "search",
     {"travelers": 4, "departure_city": "Санкт-Петербург", "duration_days": 10}),
    # 10. не о поездке
    ("Как приготовить борщ?", "other", {}),
])
def test_extraction_cases(text, expected_intent, expected_patch):
    result = analyze_text(text, state={})
    assert result.intent == expected_intent
    patch = result.patch.model_dump(exclude_none=True)
    for key, value in expected_patch.items():
        assert patch.get(key) == value, (key, patch)


def test_extraction_plan_message():
    result = analyze_text(PLAN_MESSAGE, state={})
    patch = result.patch.model_dump(exclude_none=True)
    assert patch == {
        "month": 11, "duration_days": 7, "travelers": 2, "budget_total": 120000,
        "max_flight_hours": 6.0, "weather_preference": "warm", "hotel_size": "small_or_medium",
    }
    assert result.interests_add == ["sea", "nature"]


def test_extraction_preferences_and_negation():
    result = analyze_text("Любим природу, горы и местную кухню, без пляжей", state={})
    assert set(result.interests_add) == {"nature", "mountains", "food"}
    assert result.interests_remove == ["beach"]


def test_extraction_contradiction():
    result = analyze_text("Хочу дёшево, но в пятизвёздочный люкс на Мальдивах", state={})
    assert result.contradictions


def test_extraction_budget_correction_is_modify():
    state = {"requirements": {"budget_total": 100000, "travelers": 2, "interests": []}}
    result = analyze_text("Давай лучше 80 тысяч", state=state)
    assert result.intent == "modify_trip"
    assert result.patch.budget_total == 80000


def test_extraction_relative_duration():
    state = {"requirements": {"duration_days": 7, "interests": []}}
    result = analyze_text("Сделай поездку на два дня дольше", state=state)
    assert result.patch.duration_days == 9


# --- Полный диалог -----------------------------------------------------------

def test_full_dialog():
    orch = make_orch()

    # 1. Не хватает города вылета → один вопрос, поиска нет.
    r1 = orch.handle_message(PLAN_MESSAGE)
    assert r1.action == Action.ASK_CLARIFICATION
    assert "город" in r1.reply.lower()
    assert orch.state.search_results == []

    # 2. Получили город → поиск.
    r2 = orch.handle_message("Из Москвы")
    assert r2.action == Action.SEARCH
    assert orch.state.stage == Stage.RESULTS_SHOWN
    assert orch.state.search_results[0]["id"] == "hurghada"
    assert any(e.kind == "tool_call" for e in r2.events)

    # 3. Меняем бюджет → состояние обновлено, остальное сохранено, повторный поиск.
    r3 = orch.handle_message("А если бюджет будет 80 тысяч?")
    assert r3.action == Action.SEARCH
    req = orch.state.requirements
    assert req.budget_total == 80000
    assert (req.month, req.duration_days, req.travelers, req.departure_city) == (11, 7, 2, "Москва")
    assert not any(r["fits_budget"] for r in orch.state.search_results)

    # 4. Вопрос о варианте → объяснение по фактам, без нового поиска.
    r4 = orch.handle_message("Почему Хургада?")
    assert r4.action == Action.EXPLAIN
    assert "Хургада" in r4.reply

    # 5. Выбор → только запрос подтверждения, НЕ бронь.
    r5 = orch.handle_message("Беру вариант 1")
    assert r5.action == Action.REQUEST_CONFIRMATION
    assert orch.state.stage == Stage.AWAITING_CONFIRMATION
    assert orch.state.booking_id is None
    assert "Подтверждаете" in r5.reply

    # 6. Подтверждение → имитация брони.
    r6 = orch.handle_message("Да")
    assert r6.action == Action.BOOK
    assert orch.state.stage == Stage.BOOKED
    assert orch.state.booking_id.startswith("DEMO-")

    # История хранит обе стороны диалога.
    assert len(orch.history) == 12


def test_decline_confirmation():
    orch = make_orch()
    orch.handle_message(PLAN_MESSAGE)
    orch.handle_message("Из Москвы")
    orch.handle_message("Беру вариант 1")
    r = orch.handle_message("нет")
    assert r.action == Action.CANCEL_CONFIRMATION
    assert orch.state.stage == Stage.RESULTS_SHOWN and orch.state.booking_id is None


def test_off_topic_does_not_change_state():
    orch = make_orch()
    r = orch.handle_message("Как приготовить борщ?")
    assert r.action == Action.OFF_TOPIC
    assert orch.state.requirements.month is None


def test_session_roundtrip():
    orch = make_orch()
    orch.handle_message(PLAN_MESSAGE)
    restored = TravelOrchestrator.from_dict(json.loads(json.dumps(orch.to_dict())), llm=OfflineLLM())
    assert restored.state == orch.state and restored.history == orch.history


# --- Страховка кодом ---------------------------------------------------------

class SneakyLLM(OfflineLLM):
    """Модель «жульничает»: в аргументах поиска завышает бюджет и выдумывает направление."""

    def chat(self, messages, tools=None, tool_choice=None):
        turn = super().chat(messages, tools, tool_choice)
        if turn.tool_calls:
            args = json.loads(turn.tool_calls[0].arguments)
            args.update(budget_total=10_000_000, destination="Мальдивы")
            turn.tool_calls[0] = ToolCall(turn.tool_calls[0].id, "search_destinations", json.dumps(args))
        return turn


def test_guard_overrides_model_arguments():
    orch = make_orch(SneakyLLM())
    orch.handle_message(PLAN_MESSAGE)
    r = orch.handle_message("Из Москвы")
    tool_call = next(e for e in r.events if e.kind == "tool_call")
    assert tool_call.data["arguments"]["budget_total"] == 120000
    assert tool_call.data["arguments"]["destination"] is None
    assert any("использую значение из состояния" in e.message for e in r.events)


class LazyLLM(OfflineLLM):
    """Модель игнорирует инструменты и сразу «отвечает из головы»."""

    def chat(self, messages, tools=None, tool_choice=None):
        if tools:
            return AssistantTurn("Езжайте на Бали за 10 000 ₽!")
        return super().chat(messages, tools, tool_choice)


def test_fallback_when_model_skips_tool():
    orch = make_orch(LazyLLM())
    orch.handle_message(PLAN_MESSAGE)
    r = orch.handle_message("Из Москвы")
    assert orch.state.search_results  # поиск выполнил код
    assert "Бали" not in r.reply       # выдуманный ответ не показан


class BrokenChatLLM(OfflineLLM):
    """Разбор работает, а генерация текста и tool calling падают."""

    def chat(self, messages, tools=None, tool_choice=None):
        raise LLMError("timeout")


def test_search_survives_llm_failure():
    orch = make_orch(BrokenChatLLM())
    r1 = orch.handle_message(PLAN_MESSAGE)
    assert "город" in r1.reply.lower()  # шаблонный вопрос
    r2 = orch.handle_message("Из Москвы")
    assert "Хургада" in r2.reply         # шаблонный список результатов


class BrokenParseLLM(OfflineLLM):
    def parse(self, messages, response_model):
        raise LLMError("bad json")


def test_analysis_failure_keeps_state():
    orch = make_orch(BrokenParseLLM())
    r = orch.handle_message(PLAN_MESSAGE)
    assert r.action is None and "не получилось" in r.reply.lower()
    assert orch.state.requirements.month is None


def test_rejected_value_is_reported():
    class BadBudgetLLM(OfflineLLM):
        def parse(self, messages, response_model):
            result = super().parse(messages, response_model)
            result.patch.budget_total = -1
            return result

    orch = make_orch(BadBudgetLLM())
    r = orch.handle_message("Хочу в ноябре на море")
    assert r.reply.startswith("Не смог принять")
    assert orch.state.requirements.month == 11


def test_tool_call_limit():
    class LoopingLLM(OfflineLLM):
        """Модель бесконечно вызывает поиск."""

        def chat(self, messages, tools=None, tool_choice=None):
            if tools:
                self._counter += 1
                return AssistantTurn(None, [ToolCall(f"c{self._counter}", "search_destinations", "{}")])
            return super().chat(messages, tools, tool_choice)

    orch = make_orch(LoopingLLM())
    orch.handle_message(PLAN_MESSAGE)
    r = orch.handle_message("Из Москвы")
    assert sum(e.kind == "tool_call" for e in r.events) == orch.settings.max_tool_calls
    assert orch.state.search_results
