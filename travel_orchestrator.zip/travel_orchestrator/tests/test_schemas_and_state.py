"""Тема 1 и Тема 4: валидация схем и обновление состояния."""

import pytest
from pydantic import ValidationError

from orchestrator.schemas import FieldConfidence, MessageAnalysis, Stage, TripPatch, TripRequirements, TripState
from orchestrator.state_manager import apply_analysis


def analysis(**kwargs) -> MessageAnalysis:
    """Короткий конструктор разбора для тестов."""
    base = MessageAnalysis.empty("search").model_dump()
    patch = kwargs.pop("patch", {})
    base.update(kwargs)
    base["patch"] = TripPatch(**patch)
    return MessageAnalysis.model_validate(base)


# --- TripRequirements --------------------------------------------------------

def test_negative_budget_is_rejected():
    with pytest.raises(ValidationError):
        TripRequirements(budget_total=-100)


def test_month_out_of_range_is_rejected():
    with pytest.raises(ValidationError):
        TripRequirements(month=13)


def test_departure_date_sets_month():
    req = TripRequirements(departure_date="2026-11-10")
    assert req.month == 11


def test_date_and_month_conflict():
    with pytest.raises(ValidationError):
        TripRequirements(month=12, departure_date="2026-11-10")


def test_interests_are_normalized_and_deduplicated():
    req = TripRequirements(interests=["Море", "sea", " nature ", "hiking"])
    assert req.interests == ["sea", "nature", "mountains"]


def test_missing_for_search_order():
    state = TripState(requirements=TripRequirements(month=11, travelers=2))
    assert state.missing_for_search() == ["departure_city", "duration_days"]


# --- apply_analysis -----------------------------------------------------------

def test_patch_updates_only_mentioned_fields():
    state = TripState(requirements=TripRequirements(month=11, budget_total=100000, travelers=2))
    result = apply_analysis(state, analysis(patch={"budget_total": 80000}))
    req = result.state.requirements
    assert req.budget_total == 80000
    assert req.month == 11 and req.travelers == 2  # остальное не потерялось
    assert [c.field for c in result.changes] == ["budget_total"]
    assert state.requirements.budget_total == 100000  # исходное состояние не изменено


def test_invalid_field_rejected_others_applied():
    state = TripState()
    result = apply_analysis(state, analysis(patch={"budget_total": -5, "month": 11}))
    assert result.state.requirements.month == 11
    assert result.state.requirements.budget_total is None
    assert result.rejected[0].field == "budget_total"


def test_cleared_field():
    state = TripState(requirements=TripRequirements(budget_total=100000))
    result = apply_analysis(state, analysis(cleared_fields=["budget_total"]))
    assert result.state.requirements.budget_total is None


def test_interests_add_and_remove():
    state = TripState(requirements=TripRequirements(interests=["sea", "beach"]))
    result = apply_analysis(state, analysis(interests_add=["mountains"], interests_remove=["beach"]))
    assert result.state.requirements.interests == ["sea", "mountains"]


def test_new_date_overrides_old_month():
    state = TripState(requirements=TripRequirements(month=11))
    result = apply_analysis(state, analysis(patch={"departure_date": "2026-12-05"}))
    assert result.state.requirements.month == 12
    assert not result.rejected


def test_search_change_marks_results_stale_and_resets_selection():
    state = TripState(
        requirements=TripRequirements(month=11),
        search_results=[{"id": "hurghada"}],
        selected_option_id="hurghada",
        stage=Stage.AWAITING_CONFIRMATION,
    )
    result = apply_analysis(state, analysis(patch={"budget_total": 80000}))
    assert result.state.results_stale is True
    assert result.state.selected_option_id is None
    assert result.state.stage == Stage.COLLECTING


def test_field_confidence_saved():
    result = apply_analysis(TripState(), analysis(
        patch={"travelers": 2},
        field_confidence=[FieldConfidence(field="travelers", confidence="inferred")],
    ))
    assert result.state.field_confidence == {"travelers": "inferred"}
