"""
Этап 3 плана: прогон 10 типовых сообщений через разбор.

    python -m examples.extraction_cases            # реальная LLM (нужен OPENAI_API_KEY)
    python -m examples.extraction_cases --offline  # офлайн-заглушка

Смотрите не только на валидность JSON, но и на СМЫСЛ:
правильно ли понят бюджет (на всех или на человека), не придумано ли
отсутствующее, верно ли определён intent.
"""

from __future__ import annotations

import argparse
import json

from orchestrator.config import make_llm
from orchestrator.llm_client import LLMError
from orchestrator.orchestrator import TravelOrchestrator
from orchestrator.schemas import TripRequirements, TripState

CASES: list[tuple[str, str, TripState | None]] = [
    ("полностью определённый", "Из Москвы в Хургаду в ноябре на 7 дней, 2 человека, бюджет 150 тысяч", None),
    ("без бюджета", "Хочу на море в ноябре на неделю вдвоём", None),
    ("без дат", "Бюджет 100 тысяч на двоих, хотим к морю", None),
    ("несколько предпочтений", "Любим природу, горы и местную кухню, без пляжей", None),
    ("исправление бюджета", "Давай лучше 80 тысяч",
     TripState(requirements=TripRequirements(budget_total=100000, travelers=2, month=11))),
    ("противоречие", "Хочу дёшево, но в пятизвёздочный люкс на Мальдивах", None),
    ("без направления", "Куда поехать в ноябре погреться?", None),
    ("очень короткий", "на море", None),
    ("несколько путешественников", "Нас 4 человека, летим из Питера на 10 дней", None),
    ("не о поездке", "Как приготовить борщ?", None),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    llm = make_llm(offline=args.offline)

    for title, text, state in CASES:
        orch = TravelOrchestrator(llm=llm, state=state)
        print(f"\n=== {title}: «{text}»")
        try:
            analysis = orch.analyze(text)
        except LLMError as exc:
            print("ОШИБКА:", exc)
            continue
        data = analysis.model_dump(mode="json")
        data["patch"] = {k: v for k, v in data["patch"].items() if v is not None}
        print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
