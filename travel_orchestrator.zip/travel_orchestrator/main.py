"""
Консольный чат с оркестратором.

    python main.py              # реальная LLM, если задан OPENAI_API_KEY, иначе офлайн
    python main.py --offline    # принудительно офлайн-заглушка
    python main.py --graph      # тот же ход, но через граф LangGraph
    python main.py --session s.json   # сохранять сессию между запусками

Команды в чате: /state — показать TripState, /reset — начать заново, /quit — выход.
"""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

from orchestrator.config import Settings, make_llm
from orchestrator.events import ProgressEvent
from orchestrator.offline_llm import OfflineLLM
from orchestrator.orchestrator import TravelOrchestrator

GRAY, RESET = "\033[90m", "\033[0m"


def print_event(event: ProgressEvent) -> None:
    # Пользователь видит действия агента, а не его «мысли».
    print(f"{GRAY}  · [{event.kind}] {event.message}{RESET}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Travel-оркестратор: консольный чат")
    parser.add_argument("--offline", action="store_true", help="использовать офлайн-заглушку LLM")
    parser.add_argument("--graph", action="store_true", help="выполнять ход через LangGraph")
    parser.add_argument("--session", type=Path, help="файл для сохранения сессии")
    parser.add_argument("--debug", action="store_true", help="подробные логи")
    args = parser.parse_args()

    logging.basicConfig(level=logging.DEBUG if args.debug else logging.WARNING)

    llm = make_llm(Settings.from_env(), offline=args.offline)
    if isinstance(llm, OfflineLLM):
        print("Режим: офлайн-заглушка (нет OPENAI_API_KEY или указан --offline).")
    else:
        print(f"Режим: {llm.model}")

    if args.session and args.session.exists():
        orch = TravelOrchestrator.from_dict(json.loads(args.session.read_text("utf-8")), llm=llm)
        print(f"Сессия загружена из {args.session}")
    else:
        orch = TravelOrchestrator(llm=llm)
    orch.events.subscribe(print_event)

    graph = None
    if args.graph:
        from orchestrator.graph import build_turn_graph, run_turn_with_graph
        graph = build_turn_graph(orch)

    print("Опишите поездку. Команды: /state, /reset, /quit\n")
    while True:
        try:
            text = input("Вы: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not text:
            continue
        if text == "/quit":
            break
        if text == "/state":
            print(json.dumps(orch.state.model_dump(mode="json"), ensure_ascii=False, indent=2))
            continue
        if text == "/reset":
            orch.reset()
            print("Начинаем заново.\n")
            continue

        result = run_turn_with_graph(orch, text, graph) if graph else orch.handle_message(text)
        print(f"Агент: {result.reply}\n")

        if args.session:
            args.session.write_text(json.dumps(orch.to_dict(), ensure_ascii=False, indent=2), "utf-8")


if __name__ == "__main__":
    main()
