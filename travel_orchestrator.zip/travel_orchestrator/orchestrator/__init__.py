"""LLM-оркестратор travel-агента: публичный API пакета."""

from .events import EventBus, ProgressEvent
from .llm_client import AssistantTurn, LLMClient, LLMError, OpenAIChatClient, ToolCall
from .offline_llm import OfflineLLM
from .orchestrator import OrchestratorSettings, TravelOrchestrator, TurnResult
from .router import Action, Decision, decide
from .schemas import MessageAnalysis, Stage, TripPatch, TripRequirements, TripState
from .state_manager import apply_analysis
from .tools import ToolRegistry, default_registry, search_destinations

__all__ = [
    "Action", "AssistantTurn", "Decision", "EventBus", "LLMClient", "LLMError",
    "MessageAnalysis", "OfflineLLM", "OpenAIChatClient", "OrchestratorSettings",
    "ProgressEvent", "Stage", "ToolCall", "ToolRegistry", "TravelOrchestrator",
    "TripPatch", "TripRequirements", "TripState", "TurnResult", "apply_analysis",
    "decide", "default_registry", "search_destinations",
]
