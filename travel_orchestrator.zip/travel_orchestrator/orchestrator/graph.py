"""
Тот же ход диалога, но в виде графа LangGraph (Этап 6 плана).

Граф:

    START → analyze ─┬─(ошибка)──────────────────────────────→ finish → END
                     └→ update_state → route ─┬→ ask_clarification ─┐
                                              ├→ search ────────────┤
                                              ├→ explain ───────────┤
                                              ├→ request_confirmation
                                              ├→ book ──────────────┼→ finish → END
                                              ├→ ...                │
                                              └→ off_topic ─────────┘

Понятия LangGraph:
  - State — словарь TurnGraphState, который передаётся между узлами;
    каждый узел возвращает только изменённые ключи.
  - Node — обычная Python-функция. Узел НЕ обязан вызывать LLM:
    update_state и route — чистый код.
  - Conditional edge — функция, которая по состоянию выбирает следующий узел.

Логика узлов не дублируется: они вызывают те же методы TravelOrchestrator
(analyze / apply / route / execute). Поэтому графовый и обычный режимы
ведут себя одинаково, и выбор фреймворка можно отложить.
"""

from __future__ import annotations

from typing import Any, TypedDict

from .llm_client import LLMError
from .orchestrator import TravelOrchestrator, TurnResult
from .router import Action

try:
    from langgraph.graph import END, START, StateGraph
except ImportError:  # LangGraph — опциональная зависимость
    StateGraph = None  # type: ignore[assignment,misc]


class TurnGraphState(TypedDict, total=False):
    text: str
    analysis: Any
    apply_result: Any
    decision: Any
    reply: str
    error: str
    result: TurnResult


def build_turn_graph(orch: TravelOrchestrator):
    if StateGraph is None:
        raise ImportError("LangGraph не установлен: pip install langgraph")

    def analyze(state: TurnGraphState) -> dict[str, Any]:
        orch.events.start_turn()
        try:
            return {"analysis": orch.analyze(state["text"])}
        except LLMError as exc:
            orch.events.emit("error", "Не удалось разобрать сообщение", error=str(exc))
            return {"error": str(exc),
                    "reply": "Извините, не получилось обработать сообщение. Попробуйте ещё раз."}

    def update_state(state: TurnGraphState) -> dict[str, Any]:
        return {"apply_result": orch.apply(state["analysis"])}

    def route(state: TurnGraphState) -> dict[str, Any]:
        return {"decision": orch.route(state["analysis"])}

    def make_action_node(action: Action):
        def node(state: TurnGraphState) -> dict[str, Any]:
            return {"reply": orch.execute(state["decision"], state["text"], state["analysis"])}
        node.__name__ = action.value
        return node

    def finish(state: TurnGraphState) -> dict[str, Any]:
        result = orch._finish(  # noqa: SLF001 — общий финализатор хода
            state["text"], state["reply"], state.get("decision"),
            state.get("analysis"), state.get("apply_result"),
        )
        return {"result": result}

    graph = StateGraph(TurnGraphState)
    graph.add_node("analyze", analyze)
    graph.add_node("update_state", update_state)
    graph.add_node("route", route)
    graph.add_node("finish", finish)
    for action in Action:
        graph.add_node(action.value, make_action_node(action))
        graph.add_edge(action.value, "finish")

    graph.add_edge(START, "analyze")
    # Условное ребро №1: при ошибке разбора — сразу к финалу.
    graph.add_conditional_edges("analyze", lambda s: "finish" if s.get("error") else "update_state",
                                {"finish": "finish", "update_state": "update_state"})
    graph.add_edge("update_state", "route")
    # Условное ребро №2: роутер выбирает узел-действие.
    graph.add_conditional_edges("route", lambda s: s["decision"].action.value,
                                {a.value: a.value for a in Action})
    graph.add_edge("finish", END)
    return graph.compile()


def run_turn_with_graph(orch: TravelOrchestrator, text: str, graph=None) -> TurnResult:
    graph = graph or build_turn_graph(orch)
    final_state = graph.invoke({"text": text})
    return final_state["result"]
