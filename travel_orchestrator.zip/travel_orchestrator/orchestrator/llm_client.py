"""
LLM-клиент (Этап 2 плана).

Оркестратор зависит не от конкретного SDK, а от маленького интерфейса
LLMClient с двумя методами:

    parse(messages, response_model)  -> экземпляр Pydantic-модели
        Structured Outputs: модель обязана вернуть JSON строго по схеме.

    chat(messages, tools, tool_choice) -> AssistantTurn
        Обычный ответ или запрос на вызов инструментов (function calling).

Зачем такая прослойка:
  - можно сменить провайдера (OpenAI, OpenAI-совместимый сервер, другой SDK),
    не трогая оркестратор;
  - в тестах подставляется OfflineLLM без сети и без ключа;
  - таймауты, ретраи и ошибки обрабатываются в одном месте.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Protocol, TypeVar

from pydantic import BaseModel

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


class LLMError(RuntimeError):
    """Любая ошибка обращения к модели: сеть, таймаут, отказ, битый ответ."""


@dataclass
class ToolCall:
    """Запрос модели на вызов инструмента. arguments — строка JSON."""

    id: str
    name: str
    arguments: str


@dataclass
class AssistantTurn:
    """Нормализованный ответ модели — не зависит от SDK."""

    content: str | None
    tool_calls: list[ToolCall] = field(default_factory=list)

    def to_message(self) -> dict[str, Any]:
        """
        Сообщение ассистента для истории в формате Chat Completions.
        ВАЖНО: если модель запросила инструменты, это сообщение нужно положить
        в messages перед ответами role="tool", иначе API вернёт ошибку.
        """
        message: dict[str, Any] = {"role": "assistant", "content": self.content}
        if self.tool_calls:
            message["tool_calls"] = [
                {
                    "id": call.id,
                    "type": "function",
                    "function": {"name": call.name, "arguments": call.arguments},
                }
                for call in self.tool_calls
            ]
        return message


class LLMClient(Protocol):
    def parse(self, messages: list[dict[str, Any]], response_model: type[T]) -> T: ...

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | None = None,
    ) -> AssistantTurn: ...


class OpenAIChatClient:
    """
    Реализация через официальный SDK `openai` (Chat Completions API).
    Работает и с OpenAI-совместимыми серверами через base_url
    (vLLM, LM Studio, прокси и т.п., если они поддерживают tools и json_schema).
    """

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout_s: float = 30.0,
        max_retries: int = 2,
        temperature: float = 0.2,
    ):
        try:
            from openai import OpenAI
        except ImportError as exc:  # понятная ошибка вместо трейсбэка
            raise LLMError("Не установлен пакет openai: pip install openai") from exc

        self.model = model
        self.temperature = temperature
        # SDK сам повторяет запрос при сетевых сбоях / 429 / 5xx (max_retries)
        # и обрывает слишком долгие запросы (timeout).
        self._client = OpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout_s,
            max_retries=max_retries,
        )

    # --- Structured Outputs -------------------------------------------------

    def parse(self, messages: list[dict[str, Any]], response_model: type[T]) -> T:
        import openai

        # В новых версиях SDK метод называется chat.completions.parse,
        # в старых — beta.chat.completions.parse. Поддерживаем оба.
        completions = self._client.chat.completions
        parse_fn = getattr(completions, "parse", None) or self._client.beta.chat.completions.parse

        try:
            completion = parse_fn(
                model=self.model,
                messages=messages,
                response_format=response_model,  # SDK превратит Pydantic в строгую JSON Schema
                temperature=0,  # для извлечения данных нужна детерминированность
            )
        except openai.APITimeoutError as exc:
            raise LLMError("Модель не ответила вовремя") from exc
        except openai.APIError as exc:
            raise LLMError(f"Ошибка API: {exc}") from exc
        except Exception as exc:  # например, ответ не прошёл Pydantic-валидацию
            raise LLMError(f"Не удалось разобрать ответ модели: {exc}") from exc

        message = completion.choices[0].message
        if getattr(message, "refusal", None):
            raise LLMError(f"Модель отказалась отвечать: {message.refusal}")
        if message.parsed is None:
            raise LLMError("Модель вернула пустой структурированный ответ")
        return message.parsed

    # --- Обычный ответ / function calling ------------------------------------

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | None = None,
    ) -> AssistantTurn:
        import openai

        kwargs: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
        }
        if tools:
            kwargs["tools"] = tools
            # "auto" — модель решает сама; "required" — обязана вызвать инструмент;
            # "none" — запрещено вызывать инструменты.
            kwargs["tool_choice"] = tool_choice or "auto"

        try:
            completion = self._client.chat.completions.create(**kwargs)
        except openai.APITimeoutError as exc:
            raise LLMError("Модель не ответила вовремя") from exc
        except openai.APIError as exc:
            raise LLMError(f"Ошибка API: {exc}") from exc

        message = completion.choices[0].message
        calls = [
            ToolCall(id=tc.id, name=tc.function.name, arguments=tc.function.arguments or "{}")
            for tc in (message.tool_calls or [])
            if getattr(tc, "function", None) is not None
        ]
        logger.debug("LLM ответ: content=%r tool_calls=%s", message.content, calls)
        return AssistantTurn(content=message.content, tool_calls=calls)


def read_context(messages: list[dict[str, Any]], marker: str) -> dict[str, Any]:
    """Достаёт JSON-контекст, который оркестратор кладёт в system-сообщение."""
    for message in messages:
        content = message.get("content")
        if message.get("role") == "system" and isinstance(content, str) and content.startswith(marker):
            return json.loads(content[len(marker):])
    return {}
