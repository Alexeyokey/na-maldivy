"""
Применение изменений к TripState (Тема 4 / Этап 4 плана).

LLM ПРЕДЛАГАЕТ изменения (MessageAnalysis), а этот модуль РЕШАЕТ:
  - каждое поле проверяется отдельно: одно плохое значение
    (например, бюджет -5) отклоняется, остальные изменения применяются;
  - отклонённые значения возвращаются с причиной, чтобы сказать о них
    пользователю, а не потерять молча;
  - если поменялись условия поиска, старые результаты помечаются
    устаревшими, а выбранный вариант сбрасывается.

Функция чистая: принимает старое состояние, возвращает новое,
исходный объект не меняет. Это упрощает тесты и откат.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any

from pydantic import ValidationError

from .schemas import (
    SEARCH_FIELDS,
    MessageAnalysis,
    Stage,
    TripRequirements,
    TripState,
    normalize_interest,
)


@dataclass
class FieldChange:
    field: str
    old: Any
    new: Any


@dataclass
class RejectedChange:
    field: str
    value: Any
    reason: str


@dataclass
class ApplyResult:
    state: TripState
    changes: list[FieldChange] = field(default_factory=list)
    rejected: list[RejectedChange] = field(default_factory=list)

    @property
    def search_fields_changed(self) -> bool:
        return any(c.field in SEARCH_FIELDS for c in self.changes)


def _short_error(exc: ValidationError) -> str:
    return "; ".join(e["msg"] for e in exc.errors())


def apply_analysis(state: TripState, analysis: MessageAnalysis) -> ApplyResult:
    current = state.requirements.model_dump()
    candidate: dict[str, Any] = dict(current)
    rejected: list[RejectedChange] = []

    # 1. Явно снятые ограничения.
    defaults = TripRequirements().model_dump()
    for name in analysis.cleared_fields:
        candidate[name] = defaults[name]

    # 2. Патч. exclude_none: None означает «не трогать поле».
    patch = analysis.patch.model_dump(exclude_none=True)

    # Новая дата без месяца — месяц берём из даты, иначе старый месяц
    # вступит в конфликт с новой датой.
    if "departure_date" in patch and "month" not in patch:
        try:
            patch = {"month": date.fromisoformat(patch["departure_date"]).month, **patch}
        except ValueError:
            pass  # кривую дату отклонит валидация ниже

    for name, value in patch.items():
        trial = {**candidate, name: value}
        try:
            # Проверяем ВСЮ модель с новым значением: так ловятся и
            # кросс-полевые ошибки (дата не в том месяце).
            TripRequirements.model_validate(trial)
        except ValidationError as exc:
            rejected.append(RejectedChange(name, value, _short_error(exc)))
            continue
        candidate = trial

    # 3. Интересы — инкрементально.
    if analysis.interests_add or analysis.interests_remove:
        removed = {normalize_interest(i) for i in analysis.interests_remove}
        interests = [i for i in candidate["interests"] if normalize_interest(i) not in removed]
        interests += [i for i in analysis.interests_add if normalize_interest(i) not in removed]
        candidate["interests"] = interests

    new_requirements = TripRequirements.model_validate(candidate)
    new_dump = new_requirements.model_dump()
    changes = [
        FieldChange(name, current[name], new_dump[name])
        for name in new_dump
        if new_dump[name] != current[name]
    ]

    # 4. Собираем новое состояние (старое не трогаем).
    new_state = state.model_copy(deep=True)
    new_state.requirements = new_requirements

    changed_names = {c.field for c in changes}
    for item in analysis.field_confidence:
        if item.field in changed_names:
            new_state.field_confidence[item.field] = item.confidence
    for name in analysis.cleared_fields:
        new_state.field_confidence.pop(name, None)

    result = ApplyResult(state=new_state, changes=changes, rejected=rejected)

    # 5. Условия поиска изменились → результаты устарели, выбор сброшен.
    if result.search_fields_changed:
        if new_state.search_results:
            new_state.results_stale = True
        new_state.selected_option_id = None
        new_state.stage = Stage.COLLECTING

    return result
