"""
Инструменты, которые может вызывать LLM (Тема 2: Tool / Function Calling).

Ключевая мысль: модель НЕ выполняет код. Она присылает запрос
«вызови search_destinations с такими-то аргументами» (строка JSON).
Дальше всё делает приложение:

    1. разбирает JSON аргументов;
    2. валидирует их Pydantic-моделью (SearchDestinationsArgs);
    3. вызывает обычную Python-функцию;
    4. ловит ошибки и превращает их в понятный модели ответ {"error": ...};
    5. возвращает результат модели в сообщении с role="tool".

Для каждого инструмента здесь три вещи:
    - JSON Schema параметров (её видит модель);
    - Pydantic-модель аргументов (ей проверяет код);
    - сама функция.

Схему для модели пишем руками, а не генерируем: так нагляднее, и строгий
режим OpenAI (strict=True) требует, чтобы все поля были в "required",
а необязательность выражалась типом ["integer", "null"].
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from .catalog import (
    DEPARTURE_CITIES,
    DESTINATIONS,
    estimate_cost,
    matches_destination,
    normalize_city,
)
from .schemas import HotelSize, WeatherPreference, normalize_interest

# Порог «тёплой» и «прохладной» погоды (средняя дневная температура воздуха).
WARM_MIN_TEMP_C = 22
COOL_MAX_TEMP_C = 18


# ---------------------------------------------------------------------------
# search_destinations
# ---------------------------------------------------------------------------

class SearchDestinationsArgs(BaseModel):
    """Аргументы поиска. Проверяются в коде ДО вызова функции."""

    model_config = ConfigDict(extra="forbid")

    departure_city: str
    month: int = Field(ge=1, le=12)
    duration_days: int = Field(ge=1, le=60)
    travelers: int = Field(ge=1, le=20)
    interests: list[str] = Field(default_factory=list)
    budget_total: int | None = Field(default=None, gt=0)
    max_flight_hours: float | None = Field(default=None, gt=0)
    weather_preference: WeatherPreference | None = None
    hotel_size: HotelSize | None = None
    destination: str | None = None
    limit: int = Field(default=5, ge=1, le=10)

    @field_validator("departure_city")
    @classmethod
    def _known_city(cls, value: str) -> str:
        city = normalize_city(value)
        if city is None:
            raise ValueError(
                f"неизвестный город вылета '{value}'. Доступны: {', '.join(DEPARTURE_CITIES)}"
            )
        return city

    @field_validator("interests")
    @classmethod
    def _norm_interests(cls, values: list[str]) -> list[str]:
        return [normalize_interest(v) for v in values if v.strip()]


# JSON Schema, которую увидит модель. Описания полей — это тоже промпт:
# от них зависит, насколько правильно модель заполнит аргументы.
SEARCH_DESTINATIONS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "departure_city": {"type": "string", "description": "Город вылета, например 'Москва'"},
        "month": {"type": "integer", "description": "Месяц поездки, 1–12"},
        "duration_days": {"type": "integer", "description": "Длительность поездки в днях"},
        "travelers": {"type": "integer", "description": "Количество путешественников"},
        "interests": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Теги интересов: sea, beach, nature, culture, city, "
                           "mountains, diving, shopping, surfing, food",
        },
        "budget_total": {"type": ["integer", "null"],
                         "description": "Общий бюджет на всех в рублях; null если не задан"},
        "max_flight_hours": {"type": ["number", "null"],
                             "description": "Максимальная длительность перелёта в часах"},
        "weather_preference": {"type": ["string", "null"], "enum": ["warm", "cool", "any", None]},
        "hotel_size": {"type": ["string", "null"],
                       "enum": ["small", "medium", "large", "small_or_medium", "any", None]},
        "destination": {"type": ["string", "null"],
                        "description": "Конкретное направление или страна, если пользователь его назвал"},
        "limit": {"type": "integer", "description": "Сколько вариантов вернуть, 1–10 (обычно 5)"},
    },
    "required": [
        "departure_city", "month", "duration_days", "travelers", "interests",
        "budget_total", "max_flight_hours", "weather_preference", "hotel_size",
        "destination", "limit",
    ],
    "additionalProperties": False,
}


def _hotel_ok(entry_sizes: list[str], wanted: str | None) -> bool:
    if wanted in (None, "any"):
        return True
    if wanted == "small_or_medium":
        return bool({"small", "medium"} & set(entry_sizes))
    return wanted in entry_sizes


def search_destinations(args: SearchDestinationsArgs) -> dict[str, Any]:
    """
    Поиск по синтетическому каталогу.

    Жёсткие фильтры (вариант отбрасывается):
      - нет перелёта из города вылета или он дольше max_flight_hours;
      - не подходит погода (warm / cool);
      - пользователь хочет море, а в этом месяце не сезон;
      - нет отелей нужного размера;
      - задано направление, и это не оно.

    Бюджет — МЯГКИЙ фильтр: варианты дороже бюджета возвращаются с пометкой
    fits_budget=False. Так модель сможет честно объяснить компромисс
    («на 10 000 ₽ дороже, но там есть природа»), а не молча их потерять.
    """
    results: list[dict[str, Any]] = []
    rejected_reasons: dict[str, int] = {}

    def reject(reason: str) -> None:
        rejected_reasons[reason] = rejected_reasons.get(reason, 0) + 1

    for entry in DESTINATIONS:
        if args.destination and not matches_destination(entry, args.destination):
            continue

        hours = entry["flight_hours"].get(args.departure_city)
        if hours is None:
            reject("нет перелёта из города вылета")
            continue
        if args.max_flight_hours is not None and hours > args.max_flight_hours:
            reject("перелёт дольше допустимого")
            continue

        temp = entry["avg_temp_c"][args.month - 1]
        if args.weather_preference == "warm" and temp < WARM_MIN_TEMP_C:
            reject("слишком холодно в этом месяце")
            continue
        if args.weather_preference == "cool" and temp > COOL_MAX_TEMP_C:
            reject("слишком жарко в этом месяце")
            continue

        if "sea" in args.interests and args.month not in entry["sea_months"]:
            reject("не сезон для моря")
            continue

        if not _hotel_ok(entry["hotel_sizes"], args.hotel_size):
            reject("нет отелей нужного размера")
            continue

        cost = estimate_cost(entry, args.departure_city, args.duration_days, args.travelers)
        matched = [i for i in args.interests if i in entry["tags"]]
        missing = [i for i in args.interests if i not in entry["tags"]]
        fits = args.budget_total is None or cost["total_rub"] <= args.budget_total
        over = 0 if fits else cost["total_rub"] - args.budget_total  # type: ignore[operator]

        # Простой прозрачный скоринг: его легко объяснить пользователю.
        score = 2 * len(matched) + (3 if fits else 0)
        if args.hotel_size in ("small", "small_or_medium") and "small" in entry["hotel_sizes"]:
            score += 1

        results.append({
            "id": entry["id"],
            "name": entry["name"],
            "country": entry["country"],
            "flight_hours": hours,
            "avg_temp_c": temp,
            **cost,
            "fits_budget": fits,
            "over_budget_rub": over,
            "matched_interests": matched,
            "missing_interests": missing,
            "hotel_sizes": entry["hotel_sizes"],
            "score": score,
        })

    # Сначала укладывающиеся в бюджет, затем по скору, затем дешевле.
    results.sort(key=lambda r: (not r["fits_budget"], -r["score"], r["total_rub"]))
    results = results[: args.limit]

    if not results:
        message = "Ничего не найдено. Причины отсева: " + (
            ", ".join(f"{k} ({v})" for k, v in rejected_reasons.items()) or "нет совпадений"
        )
    elif not any(r["fits_budget"] for r in results):
        message = "Подходящие направления есть, но все дороже бюджета."
    else:
        message = f"Найдено вариантов: {len(results)}."

    return {
        "results": results,
        "message": message,
        "search_params": args.model_dump(),
    }


# ---------------------------------------------------------------------------
# Реестр инструментов
# ---------------------------------------------------------------------------

@dataclass
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    args_model: type[BaseModel]
    func: Callable[[Any], dict[str, Any]]

    def openai_spec(self) -> dict[str, Any]:
        """Описание инструмента в формате Chat Completions API."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
                "strict": True,
            },
        }


@dataclass
class ToolResult:
    ok: bool
    payload: dict[str, Any]

    def to_json(self) -> str:
        return json.dumps(self.payload, ensure_ascii=False)


class ToolRegistry:
    """
    Список РАЗРЕШЁННЫХ инструментов. Модели передаём только их,
    и выполнить можно только их — даже если модель «придумает» другое имя.
    """

    def __init__(self, tools: list[Tool]):
        self._tools = {t.name: t for t in tools}

    def openai_specs(self) -> list[dict[str, Any]]:
        return [t.openai_spec() for t in self._tools.values()]

    def names(self) -> list[str]:
        return list(self._tools)

    def execute(self, name: str, arguments: dict[str, Any] | str) -> ToolResult:
        """Безопасный вызов: любые ошибки превращаются в {"error": ...}."""
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(False, {"error": f"Инструмент '{name}' не разрешён"})

        if isinstance(arguments, str):
            try:
                arguments = json.loads(arguments or "{}")
            except json.JSONDecodeError as exc:
                return ToolResult(False, {"error": f"Аргументы не являются JSON: {exc}"})

        # Модель в строгом режиме присылает null для «не задано».
        # Убираем null, чтобы сработали значения по умолчанию модели аргументов.
        cleaned = {k: v for k, v in arguments.items() if v is not None}
        try:
            args = tool.args_model.model_validate(cleaned)
        except ValidationError as exc:
            errors = "; ".join(f"{'.'.join(map(str, e['loc']))}: {e['msg']}" for e in exc.errors())
            return ToolResult(False, {"error": f"Некорректные аргументы: {errors}"})

        try:
            return ToolResult(True, tool.func(args))
        except Exception as exc:  # инструмент не должен «ронять» весь диалог
            return ToolResult(False, {"error": f"Ошибка инструмента: {exc}"})


def default_registry() -> ToolRegistry:
    return ToolRegistry([
        Tool(
            name="search_destinations",
            description=(
                "Ищет направления в каталоге по месяцу, городу вылета, длительности, "
                "числу путешественников, интересам и ограничениям. Возвращает варианты "
                "с оценкой стоимости и флагом fits_budget."
            ),
            parameters=SEARCH_DESTINATIONS_SCHEMA,
            args_model=SearchDestinationsArgs,
            func=search_destinations,
        ),
    ])
