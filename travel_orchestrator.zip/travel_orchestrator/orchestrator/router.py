"""
Роутер: выбор следующего действия (Тема 3, гибридный подход).

Решение принимает КОД, а не LLM. LLM даёт только намерение пользователя
(intent) и выбранный вариант; дальше детерминированные правила:

  - не хватает обязательных полей → уточняющий вопрос (по одному полю);
  - данных достаточно и нет свежих результатов → поиск;
  - есть результаты и вопрос → объяснение;
  - выбор варианта → показать состав поездки и ЗАПРОСИТЬ подтверждение;
  - бронь (имитация) → ТОЛЬКО если мы уже на стадии ожидания подтверждения.

Последнее правило — та самая гарантия из плана: система физически не может
перескочить от расплывчатого запроса к покупке, как бы ни ошиблась модель.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .schemas import MessageAnalysis, Stage, TripState


class Action(str, Enum):
    ASK_CLARIFICATION = "ask_clarification"
    SEARCH = "search"
    EXPLAIN = "explain"
    ASK_WHICH_OPTION = "ask_which_option"
    REQUEST_CONFIRMATION = "request_confirmation"
    BOOK = "book"
    CANCEL_CONFIRMATION = "cancel_confirmation"
    OFF_TOPIC = "off_topic"


@dataclass
class Decision:
    action: Action
    reason: str  # для логов и событий прогресса: почему выбран этот шаг
    missing_field: str | None = None
    option_id: str | None = None


def decide(state: TripState, analysis: MessageAnalysis) -> Decision:
    intent = analysis.intent
    fresh_results = bool(state.search_results) and not state.results_stale

    # --- Ожидаем подтверждения брони -------------------------------------
    if state.stage == Stage.AWAITING_CONFIRMATION:
        chosen = analysis.selected_option_id if state.find_result(analysis.selected_option_id) else None
        if intent == "confirm" and chosen in (None, state.selected_option_id):
            return Decision(Action.BOOK, "пользователь подтвердил выбранный вариант",
                            option_id=state.selected_option_id)
        if intent == "other":
            return Decision(Action.CANCEL_CONFIRMATION, "пользователь не подтвердил бронь")

    # --- Не о поездке ------------------------------------------------------
    if intent == "other":
        return Decision(Action.OFF_TOPIC, "сообщение не о поездке")

    # --- Выбор варианта ----------------------------------------------------
    if intent == "confirm" and fresh_results:
        option_id = analysis.selected_option_id if state.find_result(analysis.selected_option_id) else None
        if option_id is None and len(state.search_results) == 1:
            option_id = state.search_results[0]["id"]
        if option_id is None:
            return Decision(Action.ASK_WHICH_OPTION, "непонятно, какой вариант выбран")
        return Decision(Action.REQUEST_CONFIRMATION, "выбран вариант, нужно подтверждение",
                        option_id=option_id)

    # --- Вопрос о результатах ---------------------------------------------
    if intent == "general_question" and state.search_results:
        return Decision(Action.EXPLAIN, "вопрос по найденным вариантам")

    # --- Сбор требований и поиск ------------------------------------------
    missing = state.missing_for_search()
    if missing:
        if intent == "general_question":
            return Decision(Action.EXPLAIN, "общий вопрос до поиска")
        return Decision(Action.ASK_CLARIFICATION, f"не хватает: {', '.join(missing)}",
                        missing_field=missing[0])

    if not fresh_results:
        reason = "условия изменились, пересчитываем" if state.results_stale else "данных достаточно"
        return Decision(Action.SEARCH, reason)

    return Decision(Action.EXPLAIN, "условия поиска не изменились, комментируем текущие варианты")
