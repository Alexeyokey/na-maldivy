"""
Настройки из переменных окружения (ключи никогда не хранятся в коде).

Скопируйте .env.example в .env и заполните. Файл .env не коммитится.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # python-dotenv необязателен: можно задать переменные в shell
    pass


@dataclass(frozen=True)
class Settings:
    openai_api_key: str | None
    openai_base_url: str | None
    model: str
    timeout_s: float
    max_retries: int

    @classmethod
    def from_env(cls) -> "Settings":
        return cls(
            openai_api_key=os.getenv("OPENAI_API_KEY") or None,
            openai_base_url=os.getenv("OPENAI_BASE_URL") or None,
            model=os.getenv("LLM_MODEL", "gpt-4.1-mini"),
            timeout_s=float(os.getenv("LLM_TIMEOUT_S", "30")),
            max_retries=int(os.getenv("LLM_MAX_RETRIES", "2")),
        )


def make_llm(settings: Settings | None = None, offline: bool = False):
    """Фабрика LLM-клиента: реальный, если есть ключ, иначе офлайн-заглушка."""
    from .llm_client import OpenAIChatClient
    from .offline_llm import OfflineLLM

    settings = settings or Settings.from_env()
    if offline or not settings.openai_api_key:
        return OfflineLLM()
    return OpenAIChatClient(
        model=settings.model,
        api_key=settings.openai_api_key,
        base_url=settings.openai_base_url,
        timeout_s=settings.timeout_s,
        max_retries=settings.max_retries,
    )
