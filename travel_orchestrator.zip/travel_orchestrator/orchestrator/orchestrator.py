"""
Главный цикл оркестратора (Этап 5 плана).

Один ход диалога = handle_message(text):

    ┌────────────┐   ┌──────────────┐   ┌────────┐   ┌──────────────────┐
    │  analyze   │ → │ apply_update │ → │ route  │ → │ execute(action)  │
    │ (LLM, SO)  │   │   (код)      │   │ (код)  │   │ LLM / tools / код│
    └────────────┘   └──────────────┘   └────────┘   └──────────────────┘

  analyze      — LLM со Structured Outputs возвращает MessageAnalysis.
  apply_update — код валидирует и применяет изменения к TripState.
  route        — код выбирает действие (router.decide).
  execute      — выполняет действие:
                   ASK_CLARIFICATION    → LLM формулирует один вопрос
                   SEARCH               → мини-agent-loop с function calling
                   EXPLAIN / OFF_TOPIC  → LLM отвечает по фактам из состояния
                   REQUEST_CONFIRMATION → текст формирует КОД
                   BOOK                 → имитация брони, только код

Это и есть гибрид из плана: последовательность и критичные проверки задаёт
код; LLM понимает язык, заполняет аргументы инструментов и объясняет.
"""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Callable

from .events import EventBus, ProgressEvent
from .formatting import (
    format_confirmation,
    format_results,
    format_which_option,
    question_for,
    rub,
)
from .llm_client import AssistantTurn, LLMClient, LLMError, ToolCall
from .prompts import (
    ANALYZE_PROMPT,
    ASK_PROMPT,
    EXPLAIN_PROMPT,
    OFF_TOPIC_PROMPT,
    SEARCH_PROMPT,
    build_context_message,
)
from .router import Action, Decision, decide
from .schemas import FIELD_LABELS, MessageAnalysis, Stage, TripState
from .state_manager import ApplyResult, FieldChange, RejectedChange, apply_analysis
from .tools import ToolRegistry, default_registry

logger = logging.getLogger(__name__)

# Поля требований, которые переносятся в аргументы search_destinations.
_SEARCH_ARG_FIELDS = (
    "departure_city", "month", "duration_days", "travelers", "interests",
    "budget_total", "max_flight_hours", "weather_preference", "hotel_size", "destination",
)


@dataclass
class OrchestratorSettings:
    history_window: int = 8      # сколько последних реплик отдаём модели
    max_agent_steps: int = 4     # максимум итераций agent loop при поиске
    max_tool_calls: int = 3      # максимум вызовов инструментов за ход


@dataclass
class TurnResult:
    """Всё, что нужно UI и тестам после одного хода."""

    reply: str
    action: Action | None
    intent: str | None
    changes: list[FieldChange] = field(default_factory=list)
    rejected: list[RejectedChange] = field(default_factory=list)
    state: TripState | None = None
    events: list[ProgressEvent] = field(default_factory=list)


class TravelOrchestrator:
    def __init__(
        self,
        llm: LLMClient,
        tools: ToolRegistry | None = None,
        settings: OrchestratorSettings | None = None,
        state: TripState | None = None,
        history: list[dict[str, str]] | None = None,
        events: EventBus | None = None,
        today: Callable[[], date] = date.today,
    ):
        self.llm = llm
        self.tools = tools or default_registry()
        self.settings = settings or OrchestratorSettings()
        self.state = state or TripState()
        # История диалога — только тексты user/assistant. Служебные сообщения
        # (контекст, tool-вызовы) в историю не попадают: их источник — state.
        self.history: list[dict[str, str]] = history or []
        self.events = events or EventBus()
        self._today = today

    # ======================================================================
    # Публичный API
    # ======================================================================

    def handle_message(self, text: str) -> TurnResult:
        self.events.start_turn()

        try:
            analysis = self.analyze(text)
        except LLMError as exc:
            # Состояние не меняем: лучше переспросить, чем сохранить мусор.
            self.events.emit("error", "Не удалось разобрать сообщение", error=str(exc))
            return self._finish(text, "Извините, не получилось обработать сообщение. "
                                      "Попробуйте ещё раз или сформулируйте иначе.", None, None, None)

        apply_result = self.apply(analysis)
        decision = self.route(analysis)
        reply = self.execute(decision, text, analysis)
        return self._finish(text, reply, decision, analysis, apply_result)

    def reset(self) -> None:
        self.state = TripState()
        self.history = []

    def to_dict(self) -> dict[str, Any]:
        """Сериализация сессии (для хранения между запросами)."""
        return {"state": self.state.model_dump(mode="json"), "history": self.history}

    @classmethod
    def from_dict(cls, data: dict[str, Any], llm: LLMClient, **kwargs: Any) -> "TravelOrchestrator":
        return cls(llm=llm, state=TripState.model_validate(data["state"]),
                   history=list(data.get("history", [])), **kwargs)

    # ======================================================================
    # Шаги хода (публичные — их же использует граф LangGraph в graph.py)
    # ======================================================================

    def analyze(self, text: str) -> MessageAnalysis:
        """Шаг 1: LLM превращает сообщение в MessageAnalysis (Structured Outputs)."""
        self.events.emit("stage", "Разбираю запрос")
        messages = [
            {"role": "system", "content": ANALYZE_PROMPT},
            self._context("analyze"),
            *self._history_tail(),
            {"role": "user", "content": text},
        ]
        analysis = self.llm.parse(messages, MessageAnalysis)
        logger.debug("analysis: %s", analysis.model_dump_json())
        return analysis

    def apply(self, analysis: MessageAnalysis) -> ApplyResult:
        """Шаг 2: код проверяет и применяет изменения к состоянию."""
        result = apply_analysis(self.state, analysis)
        self.state = result.state
        if result.changes:
            self.events.emit(
                "state_update",
                "Обновил условия: " + ", ".join(FIELD_LABELS.get(c.field, c.field) for c in result.changes),
                changes=[{"field": c.field, "old": c.old, "new": c.new} for c in result.changes],
            )
        for item in result.rejected:
            self.events.emit("warning", f"Отклонено значение поля {item.field}", value=item.value,
                             reason=item.reason)
        return result

    def route(self, analysis: MessageAnalysis) -> Decision:
        """Шаг 3: код выбирает следующее действие."""
        decision = decide(self.state, analysis)
        logger.info("route: %s (%s)", decision.action.value, decision.reason)
        return decision

    def execute(self, decision: Decision, text: str, analysis: MessageAnalysis) -> str:
        """Шаг 4: выполнение действия."""
        handlers: dict[Action, Callable[[], str]] = {
            Action.ASK_CLARIFICATION: lambda: self._ask(text, decision, analysis),
            Action.SEARCH: lambda: self._search(text),
            Action.EXPLAIN: lambda: self._explain(text),
            Action.ASK_WHICH_OPTION: lambda: format_which_option(self.state.search_results),
            Action.REQUEST_CONFIRMATION: lambda: self._request_confirmation(decision),
            Action.BOOK: self._book,
            Action.CANCEL_CONFIRMATION: self._cancel_confirmation,
            Action.OFF_TOPIC: lambda: self._off_topic(text),
        }
        return handlers[decision.action]()

    # ======================================================================
    # Обработчики действий
    # ======================================================================

    def _ask(self, text: str, decision: Decision, analysis: MessageAnalysis) -> str:
        self.events.emit("stage", "Уточняю детали")
        field_name = decision.missing_field or ""
        messages = [
            {"role": "system", "content": ASK_PROMPT},
            self._context(
                "ask",
                missing_field=field_name,
                missing_field_label=FIELD_LABELS.get(field_name, field_name),
                still_missing=self.state.missing_for_search(),
                contradictions=analysis.contradictions,
            ),
            *self._history_tail(),
            {"role": "user", "content": text},
        ]
        return self._llm_text(messages, fallback=question_for(field_name))

    def _search(self, text: str) -> str:
        """
        Мини agent loop с function calling (Тема 2 + Тема 3).

        Модель может вызвать инструмент несколько раз (например, ослабить
        предпочтения), но код ограничивает число шагов и вызовов. Если
        модель так и не вызвала инструмент или упала — код вызывает
        инструмент сам с параметрами из состояния. Поиск состоится в любом
        случае.
        """
        self.events.emit("stage", "Ищу направления")
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": SEARCH_PROMPT},
            self._context("search"),
            *self._history_tail(),
            {"role": "user", "content": text},
        ]

        tool_calls_made = 0
        last_payload: dict[str, Any] | None = None
        final_text: str | None = None

        for step in range(self.settings.max_agent_steps):
            try:
                # На первом шаге требуем вызвать инструмент: нам нужны
                # реальные данные, а не ответ «из головы».
                turn = self.llm.chat(
                    messages,
                    tools=self.tools.openai_specs(),
                    tool_choice="required" if step == 0 else "auto",
                )
            except LLMError as exc:
                self.events.emit("warning", "LLM недоступна во время поиска", error=str(exc))
                break

            if not turn.tool_calls:
                final_text = turn.content  # модель закончила и объяснила результат
                break

            # Сообщение ассистента с tool_calls обязано идти ДО ответов инструментов.
            messages.append(turn.to_message())
            for call in turn.tool_calls:
                if tool_calls_made >= self.settings.max_tool_calls:
                    payload = {"error": "Лимит вызовов инструментов на этот ход исчерпан"}
                else:
                    tool_calls_made += 1
                    payload = self._run_tool(call)
                    if "results" in payload:
                        last_payload = payload
                messages.append({
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": json.dumps(payload, ensure_ascii=False),
                })

        # Фолбэк: модель не дала результатов → поиск выполняет код.
        if last_payload is None:
            self.events.emit("warning", "Модель не вызвала поиск — выполняю его напрямую")
            direct = self.tools.execute("search_destinations", self._search_args_from_state())
            if not direct.ok:
                return f"Не получилось выполнить поиск: {direct.payload.get('error')}"
            last_payload = direct.payload
            final_text = None  # прежний текст модели не опирался на эти данные

        # Сохраняем результаты в состояние — источник правды для следующих ходов.
        self.state.search_results = last_payload["results"]
        self.state.results_stale = False
        self.state.selected_option_id = None
        self.state.stage = Stage.RESULTS_SHOWN
        self.events.emit("tool_result", last_payload["message"], count=len(last_payload["results"]))

        if final_text:
            return final_text

        # Цикл исчерпан на вызове инструмента — просим финальный ответ без инструментов.
        # Результаты уже лежат в state контекста; дополнительно передаём
        # сообщение инструмента целиком (message, search_params).
        explain_messages = [
            {"role": "system", "content": SEARCH_PROMPT +
             "\nИнструменты больше не вызывай: результаты поиска — в search_payload контекста."},
            self._context("search_summary", search_payload=last_payload),
            *self._history_tail(),
            {"role": "user", "content": text},
        ]
        return self._llm_text(explain_messages, fallback=format_results(last_payload))

    def _run_tool(self, call: ToolCall) -> dict[str, Any]:
        """Проверка аргументов, «страховка» состоянием и вызов инструмента."""
        try:
            args = json.loads(call.arguments or "{}")
        except json.JSONDecodeError:
            args = {}
        if call.name == "search_destinations" and isinstance(args, dict):
            args = self._guard_search_args(args)

        self.events.emit("tool_call", f"Вызываю {call.name}", arguments=args)
        result = self.tools.execute(call.name, args)
        if not result.ok:
            self.events.emit("warning", f"Инструмент {call.name} вернул ошибку",
                             error=result.payload.get("error"))
        return result.payload

    def _guard_search_args(self, args: dict[str, Any]) -> dict[str, Any]:
        """
        Модель не имеет права менять условия поиска: источник правды — TripState.
          - Жёсткие условия (город, месяц, бюджет, перелёт…) всегда берутся
            из состояния. Модель не может ни изменить их, ни «придумать»
            ограничение, которого пользователь не задавал.
          - Интересы — мягкие: модели разрешено ОСЛАБИТЬ их (передать
            подмножество) при повторном поиске, но не добавить новые.
          - limit модель выбирает сама.
        """
        req = self.state.requirements.model_dump(mode="json")
        guarded = dict(args)
        for name in _SEARCH_ARG_FIELDS:
            state_value = req.get(name)
            model_value = guarded.get(name)
            if name == "interests":
                if model_value is None or not set(model_value) <= set(state_value):
                    guarded["interests"] = state_value
                continue
            if model_value != state_value:
                if model_value is not None:
                    self.events.emit("warning", f"Модель изменила {name} — использую значение из состояния",
                                     model_value=model_value, state_value=state_value)
                guarded[name] = state_value
        return guarded

    def _search_args_from_state(self) -> dict[str, Any]:
        req = self.state.requirements.model_dump(mode="json")
        return {name: req.get(name) for name in _SEARCH_ARG_FIELDS}

    def _explain(self, text: str) -> str:
        self.events.emit("stage", "Готовлю ответ")
        messages = [
            {"role": "system", "content": EXPLAIN_PROMPT},
            self._context("explain"),
            *self._history_tail(),
            {"role": "user", "content": text},
        ]
        fallback = (format_results({"results": self.state.search_results, "message": "Текущие варианты:"})
                    if self.state.search_results else "Пока у меня нет данных, чтобы ответить точно.")
        return self._llm_text(messages, fallback=fallback)

    def _request_confirmation(self, decision: Decision) -> str:
        option = self.state.find_result(decision.option_id)
        if option is None:  # защита от рассинхрона
            return format_which_option(self.state.search_results)
        self.state.selected_option_id = option["id"]
        self.state.stage = Stage.AWAITING_CONFIRMATION
        self.events.emit("stage", "Жду подтверждения", option_id=option["id"])
        return format_confirmation(option, self.state.requirements)

    def _book(self) -> str:
        # Двойная проверка инварианта: бронь только из стадии ожидания.
        option = self.state.find_result(self.state.selected_option_id)
        if self.state.stage != Stage.AWAITING_CONFIRMATION or option is None:
            return "Сначала выберите вариант — я покажу состав поездки и попрошу подтверждение."
        self.state.booking_id = "DEMO-" + uuid.uuid4().hex[:8].upper()
        self.state.stage = Stage.BOOKED
        self.events.emit("stage", "Бронирование (имитация) выполнено", booking_id=self.state.booking_id)
        return (f"Готово! Демо-бронь {self.state.booking_id}: {option['name']}, "
                f"сумма ~{rub(option['total_rub'])}. Это имитация — реального бронирования не было.")

    def _cancel_confirmation(self) -> str:
        self.state.stage = Stage.RESULTS_SHOWN
        self.state.selected_option_id = None
        return "Хорошо, не бронирую. Можно выбрать другой вариант или изменить условия."

    def _off_topic(self, text: str) -> str:
        messages = [
            {"role": "system", "content": OFF_TOPIC_PROMPT},
            *self._history_tail(),
            {"role": "user", "content": text},
        ]
        return self._llm_text(messages, fallback="Я помогаю планировать поездки. "
                                                 "Расскажите, куда и когда хотите поехать?")

    # ======================================================================
    # Вспомогательное
    # ======================================================================

    def _context(self, task: str, **extra: Any) -> dict[str, Any]:
        return build_context_message(task, self.state, self._today(), **extra)

    def _history_tail(self) -> list[dict[str, str]]:
        window = self.settings.history_window
        return self.history[-window:] if window > 0 else []

    def _llm_text(self, messages: list[dict[str, Any]], fallback: str) -> str:
        """Текстовый ответ модели; при ошибке — детерминированный фолбэк."""
        try:
            turn: AssistantTurn = self.llm.chat(messages)
        except LLMError as exc:
            self.events.emit("warning", "LLM недоступна, отвечаю шаблоном", error=str(exc))
            return fallback
        return (turn.content or "").strip() or fallback

    def _finish(
        self,
        text: str,
        reply: str,
        decision: Decision | None,
        analysis: MessageAnalysis | None,
        apply_result: ApplyResult | None,
    ) -> TurnResult:
        # Сообщаем пользователю об отклонённых значениях — честно, а не молча.
        if apply_result and apply_result.rejected:
            notes = "; ".join(
                f"{FIELD_LABELS.get(r.field, r.field)} = {r.value!r} ({r.reason})"
                for r in apply_result.rejected
            )
            reply = f"Не смог принять: {notes}.\n{reply}"

        self.history.append({"role": "user", "content": text})
        self.history.append({"role": "assistant", "content": reply})

        return TurnResult(
            reply=reply,
            action=decision.action if decision else None,
            intent=analysis.intent if analysis else None,
            changes=apply_result.changes if apply_result else [],
            rejected=apply_result.rejected if apply_result else [],
            state=self.state.model_copy(deep=True),
            events=list(self.events.turn_events),
        )
