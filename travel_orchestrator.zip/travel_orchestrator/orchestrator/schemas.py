"""
Схемы данных оркестратора (Тема 1 плана: Structured Outputs + Pydantic).

Здесь три группы моделей, и важно не путать их назначение:

1. TripRequirements — «чистые» требования к поездке. Это доменная модель
   с валидаторами: она гарантирует, что в состоянии никогда не окажется
   отрицательный бюджет, 13-й месяц или 0 путешественников.

2. TripState — состояние сессии: требования + служебные поля оркестратора
   (стадия диалога, последние результаты поиска, выбранный вариант).
   Этим владеет ТОЛЬКО программа. LLM никогда не пишет в TripState напрямую.

3. MessageAnalysis (+ TripPatch) — то, что возвращает LLM через
   Structured Outputs: намерение пользователя и ПРЕДЛАГАЕМЫЕ изменения.
   Программа сама решает, применять их или нет (см. state_manager.py).

Почему так: Structured Outputs гарантирует ФОРМУ ответа (валидный JSON по
схеме), а Pydantic-валидация в TripRequirements гарантирует СМЫСЛ
(бюджет > 0, месяц 1–12 и т.д.). Одно не заменяет другое.
"""

from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# ---------------------------------------------------------------------------
# Перечисления (Literal превращаются в "enum" в JSON Schema — модель
# физически не сможет вернуть значение вне списка).
# ---------------------------------------------------------------------------

# Типы запросов из Темы 5 плана.
Intent = Literal[
    "inspiration",       # «Куда поехать в ноябре?»
    "search",            # «Найди отель в Сочи на 5 дней»
    "modify_trip",       # «Сделай поездку на два дня дольше»
    "general_question",  # «Почему ты выбрал этот отель?»
    "confirm",           # «Да, этот вариант подходит»
    "other",             # не о поездке
]

WeatherPreference = Literal["warm", "cool", "any"]
HotelSize = Literal["small", "medium", "large", "small_or_medium", "any"]

# explicit — пользователь сказал прямо («бюджет 120 тысяч»);
# inferred — выведено («с девушкой» → 2 путешественника).
Confidence = Literal["explicit", "inferred"]

# Имена полей, которые LLM может менять/очищать. Держим их в одном месте,
# чтобы LLM не могла «сочинить» несуществующее поле.
TripField = Literal[
    "destination",
    "departure_city",
    "month",
    "departure_date",
    "duration_days",
    "travelers",
    "budget_total",
    "currency",
    "max_flight_hours",
    "weather_preference",
    "interests",
    "hotel_size",
]

# Словарь интересов. Каталог размечен этими тегами, поэтому LLM просим
# использовать именно их. Всё, что пришло в другом виде, нормализуем.
INTEREST_VOCABULARY: tuple[str, ...] = (
    "sea", "beach", "nature", "culture", "city",
    "mountains", "diving", "shopping", "surfing", "food",
)

INTEREST_SYNONYMS: dict[str, str] = {
    "море": "sea", "ocean": "sea", "seaside": "sea",
    "пляж": "beach", "beaches": "beach",
    "природа": "nature", "parks": "nature", "wildlife": "nature",
    "культура": "culture", "museums": "culture", "history": "culture",
    "город": "city", "cities": "city",
    "горы": "mountains", "hiking": "mountains", "trekking": "mountains",
    "дайвинг": "diving", "snorkeling": "diving",
    "шопинг": "shopping",
    "серфинг": "surfing", "surf": "surfing",
    "еда": "food", "gastronomy": "food", "cuisine": "food",
}

# Поля, изменение которых делает прежние результаты поиска неактуальными.
SEARCH_FIELDS: frozenset[str] = frozenset({
    "destination", "departure_city", "month", "departure_date",
    "duration_days", "travelers", "budget_total", "max_flight_hours",
    "weather_preference", "interests", "hotel_size",
})

# Минимум, без которого поиск не запускаем (решение принимает КОД, а не LLM).
# Порядок важен: спрашиваем в этом порядке, по одному вопросу за раз.
# Бюджет сюда сознательно не входит: без него можно искать и показать цены.
REQUIRED_FOR_SEARCH: tuple[str, ...] = (
    "departure_city",
    "month",
    "duration_days",
    "travelers",
)

# Человекочитаемые названия полей — для вопросов и сообщений об ошибках.
FIELD_LABELS: dict[str, str] = {
    "destination": "направление",
    "departure_city": "город вылета",
    "month": "месяц поездки",
    "departure_date": "дата вылета",
    "duration_days": "длительность поездки",
    "travelers": "количество путешественников",
    "budget_total": "общий бюджет",
    "currency": "валюта",
    "max_flight_hours": "максимальная длительность перелёта",
    "weather_preference": "погода",
    "interests": "интересы",
    "hotel_size": "размер отеля",
}


def normalize_interest(raw: str) -> str:
    """Приводит интерес к тегу каталога: 'Море ' -> 'sea'."""
    value = raw.strip().lower()
    return INTEREST_SYNONYMS.get(value, value)


# ---------------------------------------------------------------------------
# 1. Доменная модель требований
# ---------------------------------------------------------------------------

class TripRequirements(BaseModel):
    """Текущие требования пользователя к поездке. None = «пока неизвестно»."""

    # extra="forbid": опечатка в имени поля — это ошибка, а не тихо
    # проигнорированное значение.
    model_config = ConfigDict(extra="forbid")

    destination: str | None = None
    departure_city: str | None = None
    # month объявлен ДО departure_date: при пошаговом применении патча
    # (state_manager) месяц обновляется раньше даты.
    month: int | None = Field(default=None, ge=1, le=12)
    departure_date: date | None = None
    duration_days: int | None = Field(default=None, ge=1, le=60)
    travelers: int | None = Field(default=None, ge=1, le=20)
    budget_total: int | None = Field(default=None, gt=0, description="Общий бюджет на всех")
    currency: str = "RUB"
    max_flight_hours: float | None = Field(default=None, gt=0, le=30)
    weather_preference: WeatherPreference | None = None
    interests: list[str] = Field(default_factory=list)
    hotel_size: HotelSize | None = None

    @field_validator("destination", "departure_city", mode="before")
    @classmethod
    def _strip_text(cls, value: Any) -> Any:
        # Пустую строку от модели считаем «неизвестно», а не названием города.
        if isinstance(value, str):
            value = value.strip()
            return value or None
        return value

    @field_validator("currency")
    @classmethod
    def _check_currency(cls, value: str) -> str:
        value = value.strip().upper()
        if len(value) != 3 or not value.isalpha():
            raise ValueError("валюта должна быть трёхбуквенным кодом, например RUB")
        return value

    @field_validator("interests")
    @classmethod
    def _normalize_interests(cls, values: list[str]) -> list[str]:
        # Нормализуем и убираем дубликаты, сохраняя порядок.
        result: list[str] = []
        for raw in values:
            tag = normalize_interest(raw)
            if tag and tag not in result:
                result.append(tag)
        return result

    @model_validator(mode="after")
    def _sync_month_with_date(self) -> "TripRequirements":
        # Кросс-полевая проверка: конкретная дата задаёт месяц.
        # Это пример логики, которую JSON Schema выразить не может.
        if self.departure_date is not None:
            if self.month is None:
                self.month = self.departure_date.month
            elif self.month != self.departure_date.month:
                raise ValueError(
                    f"дата {self.departure_date.isoformat()} не попадает в месяц {self.month}"
                )
        return self


# ---------------------------------------------------------------------------
# 2. Состояние сессии (владелец — программа)
# ---------------------------------------------------------------------------

class Stage(str, Enum):
    """Стадии диалога — упрощённая state machine (Тема 3)."""

    COLLECTING = "collecting"                        # собираем требования
    RESULTS_SHOWN = "results_shown"                  # показали варианты
    AWAITING_CONFIRMATION = "awaiting_confirmation"  # ждём «да» перед бронью
    BOOKED = "booked"                                # имитация брони выполнена


class TripState(BaseModel):
    """Полное состояние поездки в текущей сессии."""

    requirements: TripRequirements = Field(default_factory=TripRequirements)
    stage: Stage = Stage.COLLECTING
    # Результаты последнего поиска в том виде, в каком их вернул инструмент.
    search_results: list[dict[str, Any]] = Field(default_factory=list)
    # True, если после поиска поменялись условия и результаты устарели.
    results_stale: bool = False
    selected_option_id: str | None = None
    booking_id: str | None = None
    # Уверенность по каждому полю (explicit / inferred).
    field_confidence: dict[str, Confidence] = Field(default_factory=dict)

    def missing_for_search(self) -> list[str]:
        """Каких обязательных полей не хватает для поиска (в порядке вопросов)."""
        req = self.requirements
        return [name for name in REQUIRED_FOR_SEARCH if getattr(req, name) is None]

    def find_result(self, option_id: str | None) -> dict[str, Any] | None:
        """Ищет вариант по id среди текущих результатов."""
        if not option_id:
            return None
        return next((r for r in self.search_results if r.get("id") == option_id), None)


# ---------------------------------------------------------------------------
# 3. Что возвращает LLM (Structured Outputs)
# ---------------------------------------------------------------------------
# Требования строгого режима OpenAI: все поля обязательны, а «необязательность»
# выражается типом `X | None`. Поэтому здесь:
#   - нет значений по умолчанию у списков (default=[] строгий режим не любит);
#   - None означает «пользователь об этом НЕ говорил в новом сообщении».

class TripPatch(BaseModel):
    """Изменения, которые LLM предлагает внести в TripRequirements."""

    model_config = ConfigDict(extra="forbid")

    destination: str | None = None
    departure_city: str | None = None
    month: int | None = None
    departure_date: str | None = Field(default=None, description="YYYY-MM-DD")
    duration_days: int | None = None
    travelers: int | None = None
    budget_total: int | None = None
    currency: str | None = None
    max_flight_hours: float | None = None
    weather_preference: WeatherPreference | None = None
    hotel_size: HotelSize | None = None


class FieldConfidence(BaseModel):
    model_config = ConfigDict(extra="forbid")

    field: TripField
    confidence: Confidence


class MessageAnalysis(BaseModel):
    """Результат разбора одного сообщения пользователя."""

    model_config = ConfigDict(extra="forbid")

    intent: Intent
    patch: TripPatch
    # Интересы меняются инкрементально: «ещё любим горы» не должно стирать «море».
    interests_add: list[str]
    interests_remove: list[str]
    # Явное снятие ограничения: «бюджет не важен» -> ["budget_total"].
    cleared_fields: list[TripField]
    field_confidence: list[FieldConfidence]
    # Замеченные противоречия — показываем пользователю, но не «чиним» молча.
    contradictions: list[str]
    # Если пользователь выбрал вариант из результатов поиска.
    selected_option_id: str | None

    @classmethod
    def empty(cls, intent: Intent = "other") -> "MessageAnalysis":
        """Пустой разбор — удобно в тестах и как безопасный фолбэк."""
        return cls(
            intent=intent,
            patch=TripPatch(),
            interests_add=[],
            interests_remove=[],
            cleared_fields=[],
            field_confidence=[],
            contradictions=[],
            selected_option_id=None,
        )
