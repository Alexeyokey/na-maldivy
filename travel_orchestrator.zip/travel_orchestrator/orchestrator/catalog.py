"""
Синтетический каталог направлений.

Все цифры ВЫДУМАНЫ и нужны только для прототипа. Когда команда утвердит
формат каталога и теги, заменяется только этот файл и функция поиска
в tools.py — оркестратор от структуры каталога не зависит.

Модель стоимости (тоже упрощённая):
    стоимость = путешественники × (перелёт_туда_обратно + дневные_расходы × дни)
где дневные расходы = проживание + питание на одного человека.
"""

from __future__ import annotations

from typing import Any

# Города вылета, которые знает каталог.
DEPARTURE_CITIES: tuple[str, ...] = (
    "Москва", "Санкт-Петербург", "Казань", "Екатеринбург", "Новосибирск",
)

# Основы слов для распознавания города в свободной форме
# («из Москвы», «Питер», «СПб»).
CITY_STEMS: tuple[tuple[str, str], ...] = (
    ("москв", "Москва"),
    ("мск", "Москва"),
    ("петербург", "Санкт-Петербург"),
    ("питер", "Санкт-Петербург"),
    ("спб", "Санкт-Петербург"),
    ("казан", "Казань"),
    ("екатеринбург", "Екатеринбург"),
    ("екб", "Екатеринбург"),
    ("новосибирск", "Новосибирск"),
)

# Цены перелёта в каталоге заданы из Москвы; из других городов — с коэффициентом.
FLIGHT_PRICE_MULTIPLIER: dict[str, float] = {
    "Москва": 1.0,
    "Санкт-Петербург": 1.1,
    "Казань": 1.05,
    "Екатеринбург": 1.15,
    "Новосибирск": 1.3,
}

# Средняя дневная температура воздуха по месяцам (январь..декабрь).
_HOT_ALL_YEAR = [30, 30, 31, 32, 31, 30, 30, 30, 30, 30, 30, 30]

DESTINATIONS: list[dict[str, Any]] = [
    {
        "id": "hurghada",
        "name": "Хургада",
        "country": "Египет",
        "aliases": ["хургад", "hurghada", "египет", "егип"],
        "tags": ["sea", "beach", "diving"],
        "hotel_sizes": ["medium", "large"],
        "flight_hours": {"Москва": 5.0, "Санкт-Петербург": 5.5, "Казань": 5.0,
                         "Екатеринбург": 6.0, "Новосибирск": 8.0},
        "flight_price_rub": 28000,
        "daily_cost_rub": 4500,
        "avg_temp_c": [21, 22, 24, 28, 31, 34, 35, 35, 33, 30, 26, 22],
        "sea_months": list(range(1, 13)),
    },
    {
        "id": "sharm",
        "name": "Шарм-эль-Шейх",
        "country": "Египет",
        "aliases": ["шарм", "sharm", "египет", "егип"],
        "tags": ["sea", "beach", "diving", "nature"],
        "hotel_sizes": ["small", "medium", "large"],
        "flight_hours": {"Москва": 5.0, "Санкт-Петербург": 5.5, "Казань": 5.0,
                         "Екатеринбург": 6.0, "Новосибирск": 8.0},
        "flight_price_rub": 30000,
        "daily_cost_rub": 5000,
        "avg_temp_c": [22, 23, 25, 29, 32, 35, 35, 35, 33, 30, 27, 23],
        "sea_months": list(range(1, 13)),
    },
    {
        "id": "antalya",
        "name": "Анталья",
        "country": "Турция",
        "aliases": ["анталь", "antalya", "турци"],
        "tags": ["sea", "beach", "culture", "nature"],
        "hotel_sizes": ["small", "medium", "large"],
        "flight_hours": {"Москва": 4.0, "Санкт-Петербург": 4.5, "Казань": 4.0,
                         "Екатеринбург": 5.0, "Новосибирск": 7.0},
        "flight_price_rub": 24000,
        "daily_cost_rub": 5500,
        "avg_temp_c": [15, 15, 17, 20, 25, 30, 33, 33, 30, 25, 20, 16],
        "sea_months": [5, 6, 7, 8, 9, 10],
    },
    {
        "id": "dubai",
        "name": "Дубай",
        "country": "ОАЭ",
        "aliases": ["дубай", "dubai", "оаэ", "эмират"],
        "tags": ["city", "beach", "sea", "shopping"],
        "hotel_sizes": ["medium", "large"],
        "flight_hours": {"Москва": 5.0, "Санкт-Петербург": 5.5, "Казань": 5.0,
                         "Екатеринбург": 4.5, "Новосибирск": 6.0},
        "flight_price_rub": 32000,
        "daily_cost_rub": 9000,
        "avg_temp_c": [24, 25, 28, 33, 38, 40, 41, 41, 39, 35, 30, 26],
        "sea_months": list(range(1, 13)),
    },
    {
        "id": "gagra",
        "name": "Гагра",
        "country": "Абхазия",
        "aliases": ["гагр", "абхаз"],
        "tags": ["sea", "nature", "mountains"],
        "hotel_sizes": ["small", "medium"],
        "flight_hours": {"Москва": 2.5, "Санкт-Петербург": 3.0, "Казань": 2.5,
                         "Екатеринбург": 3.5, "Новосибирск": 5.0},
        "flight_price_rub": 12000,
        "daily_cost_rub": 3500,
        "avg_temp_c": [10, 11, 13, 17, 21, 25, 28, 28, 25, 20, 15, 12],
        "sea_months": [6, 7, 8, 9, 10],
    },
    {
        "id": "sochi",
        "name": "Сочи",
        "country": "Россия",
        "aliases": ["сочи", "адлер", "sochi"],
        "tags": ["sea", "mountains", "nature", "city"],
        "hotel_sizes": ["small", "medium", "large"],
        "flight_hours": {"Москва": 2.5, "Санкт-Петербург": 3.0, "Казань": 2.5,
                         "Екатеринбург": 3.5, "Новосибирск": 5.0},
        "flight_price_rub": 12000,
        "daily_cost_rub": 6000,
        "avg_temp_c": [10, 10, 12, 16, 20, 24, 27, 28, 24, 19, 15, 12],
        "sea_months": [6, 7, 8, 9, 10],
    },
    {
        "id": "phuket",
        "name": "Пхукет",
        "country": "Таиланд",
        "aliases": ["пхукет", "phuket", "таиланд", "тайланд"],
        "tags": ["sea", "beach", "nature", "diving", "food"],
        "hotel_sizes": ["small", "medium", "large"],
        "flight_hours": {"Москва": 9.5, "Санкт-Петербург": 10.0, "Казань": 9.5,
                         "Екатеринбург": 9.0, "Новосибирск": 8.5},
        "flight_price_rub": 55000,
        "daily_cost_rub": 5500,
        "avg_temp_c": [32, 33, 33, 33, 32, 31, 31, 31, 31, 31, 31, 31],
        "sea_months": [11, 12, 1, 2, 3, 4],
    },
    {
        "id": "nhatrang",
        "name": "Нячанг",
        "country": "Вьетнам",
        "aliases": ["нячанг", "вьетнам", "nha trang"],
        "tags": ["sea", "beach", "food"],
        "hotel_sizes": ["medium", "large"],
        "flight_hours": {"Москва": 9.0, "Санкт-Петербург": 9.5, "Казань": 9.0,
                         "Екатеринбург": 8.5, "Новосибирск": 7.5},
        "flight_price_rub": 50000,
        "daily_cost_rub": 3500,
        "avg_temp_c": [27, 28, 29, 30, 31, 32, 32, 32, 31, 29, 28, 27],
        "sea_months": [2, 3, 4, 5, 6, 7, 8],
    },
    {
        "id": "hikkaduwa",
        "name": "Хиккадува",
        "country": "Шри-Ланка",
        "aliases": ["хиккадув", "шри-ланк", "шри ланк", "ланк"],
        "tags": ["sea", "nature", "culture", "surfing"],
        "hotel_sizes": ["small", "medium"],
        "flight_hours": {"Москва": 9.0, "Санкт-Петербург": 9.5, "Казань": 9.5,
                         "Екатеринбург": 9.0, "Новосибирск": 9.0},
        "flight_price_rub": 52000,
        "daily_cost_rub": 4000,
        "avg_temp_c": _HOT_ALL_YEAR,
        "sea_months": [11, 12, 1, 2, 3, 4],
    },
    {
        "id": "maldives",
        "name": "Мальдивы",
        "country": "Мальдивы",
        "aliases": ["мальдив", "maldives"],
        "tags": ["sea", "beach", "diving", "nature"],
        "hotel_sizes": ["small", "medium"],
        "flight_hours": {"Москва": 8.0, "Санкт-Петербург": 8.5, "Казань": 8.0,
                         "Екатеринбург": 7.5, "Новосибирск": 7.0},
        "flight_price_rub": 60000,
        "daily_cost_rub": 15000,
        "avg_temp_c": _HOT_ALL_YEAR,
        "sea_months": list(range(1, 13)),
    },
    {
        "id": "kazan",
        "name": "Казань",
        "country": "Россия",
        "aliases": ["казан", "kazan"],
        "tags": ["city", "culture", "food"],
        "hotel_sizes": ["small", "medium", "large"],
        # None = прямого перелёта нет (из Казани в Казань не летают).
        "flight_hours": {"Москва": 1.5, "Санкт-Петербург": 2.0, "Казань": None,
                         "Екатеринбург": 2.0, "Новосибирск": 4.0},
        "flight_price_rub": 8000,
        "daily_cost_rub": 5000,
        "avg_temp_c": [-10, -9, -3, 7, 16, 21, 23, 21, 15, 7, -1, -7],
        "sea_months": [],
    },
    {
        "id": "altai",
        "name": "Горный Алтай",
        "country": "Россия",
        "aliases": ["алта", "altai"],
        "tags": ["nature", "mountains"],
        "hotel_sizes": ["small"],
        "flight_hours": {"Москва": 4.5, "Санкт-Петербург": 5.0, "Казань": 4.0,
                         "Екатеринбург": 2.5, "Новосибирск": 1.0},
        "flight_price_rub": 20000,
        "daily_cost_rub": 3500,
        "avg_temp_c": [-15, -12, -4, 6, 14, 19, 21, 18, 11, 4, -6, -13],
        "sea_months": [],
    },
]


def normalize_city(name: str | None) -> str | None:
    """'из москвы' / 'Питер' / 'СПб' -> каноническое название или None."""
    if not name:
        return None
    text = name.strip().lower().replace("ё", "е")
    for stem, city in CITY_STEMS:
        if stem in text:
            return city
    return None


def matches_destination(entry: dict[str, Any], query: str) -> bool:
    """Подходит ли запись каталога под название направления/страны."""
    q = query.strip().lower().replace("ё", "е")
    if not q:
        return False
    if q in entry["name"].lower() or q in entry["country"].lower():
        return True
    return any(alias in q for alias in entry["aliases"])


def estimate_cost(entry: dict[str, Any], departure_city: str,
                  duration_days: int, travelers: int) -> dict[str, int]:
    """Оценка стоимости поездки. Считается в коде, а не в LLM."""
    multiplier = FLIGHT_PRICE_MULTIPLIER.get(departure_city, 1.0)
    flight = round(entry["flight_price_rub"] * multiplier) * travelers
    stay = entry["daily_cost_rub"] * duration_days * travelers
    return {"flight_cost_rub": flight, "stay_cost_rub": stay, "total_rub": flight + stay}
