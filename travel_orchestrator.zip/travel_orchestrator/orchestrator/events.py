"""
События прогресса (Этап 6 плана).

Интерфейсу не нужны внутренние рассуждения модели. Ему нужны короткие
статусы: «Разбираю запрос», «Ищу направления», «Нашёл 3 варианта».
Оркестратор публикует события, а UI (CLI, веб-сокет, SSE) подписывается.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Literal

EventKind = Literal["stage", "state_update", "tool_call", "tool_result", "warning", "error"]


@dataclass
class ProgressEvent:
    kind: EventKind
    message: str
    data: dict[str, Any] = field(default_factory=dict)
    ts: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class EventBus:
    """Простейшая шина: список подписчиков + журнал событий текущего хода."""

    def __init__(self) -> None:
        self._subscribers: list[Callable[[ProgressEvent], None]] = []
        self.turn_events: list[ProgressEvent] = []

    def subscribe(self, callback: Callable[[ProgressEvent], None]) -> None:
        self._subscribers.append(callback)

    def start_turn(self) -> None:
        self.turn_events = []

    def emit(self, kind: EventKind, message: str, **data: Any) -> ProgressEvent:
        event = ProgressEvent(kind=kind, message=message, data=data)
        self.turn_events.append(event)
        for callback in self._subscribers:
            try:
                callback(event)
            except Exception:  # сломанный подписчик не должен ломать диалог
                pass
        return event
