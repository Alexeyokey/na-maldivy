"""
OfflineLLM — эвристическая заглушка вместо настоящей модели.

Зачем:
  - тесты оркестратора идут без сети, без ключа и детерминированно;
  - можно показать капитану рабочий цикл, пока не выбран провайдер;
  - видно, что оркестратор действительно не зависит от конкретной LLM.

Это НЕ замена LLM. Регулярные выражения понимают только типовые фразы.
Реальное понимание языка даёт OpenAIChatClient. Заглушка реализует тот же
интерфейс (parse + chat), и в этом весь смысл абстракции LLMClient.
"""

from __future__ import annotations

import json
import re
from typing import Any

from pydantic import BaseModel

from .catalog import CITY_STEMS, DESTINATIONS
from .formatting import describe_result, format_results, question_for
from .llm_client import AssistantTurn, LLMError, ToolCall, read_context
from .prompts import CONTEXT_MARKER
from .schemas import FieldConfidence, MessageAnalysis, TripPatch

# ---------------------------------------------------------------------------
# Словари
# ---------------------------------------------------------------------------

MONTH_PATTERNS: list[tuple[str, int]] = [
    (r"январ", 1), (r"феврал", 2), (r"\bмарт", 3), (r"апрел", 4),
    (r"\bма[йяе]\b", 5), (r"\bиюн", 6), (r"\bиюл", 7), (r"август", 8),
    (r"сентябр", 9), (r"октябр", 10), (r"ноябр", 11), (r"декабр", 12),
]

WORD_NUMBERS: dict[str, int] = {
    "один": 1, "одна": 1, "два": 2, "две": 2, "три": 3, "четыре": 4, "пять": 5,
    "шесть": 6, "семь": 7, "восемь": 8, "девять": 9, "десять": 10,
}
_NUM = r"(\d+|" + "|".join(WORD_NUMBERS) + r")"

INTEREST_PATTERNS: list[tuple[str, str]] = [
    (r"мор[еяю]|морск", "sea"),
    (r"пляж", "beach"),
    (r"природ|заповед|национальн\w* парк", "nature"),
    (r"\bгор(?:ы|ах|ам)\b|поход|треккинг", "mountains"),
    (r"дайв|снорк|риф", "diving"),
    (r"музе|экскурс|истори|культур|архитектур", "culture"),
    (r"шопинг|магазин", "shopping"),
    (r"серф", "surfing"),
    (r"гастро|местн\w* кухн", "food"),
]

# Слова, по которым понятно, что речь о поездке (для intent=other).
TRIP_WORDS = r"поезд|поех|отдох|отдых|отел|тур\b|туры|вариант|перел|бюджет|направлен|отпуск|путешеств|билет|виз|курорт"

ORDINALS: dict[str, int] = {"перв": 1, "втор": 2, "трет": 3, "четв": 4, "пят": 5}


def _num(token: str) -> int:
    return int(token) if token.isdigit() else WORD_NUMBERS[token]


# ---------------------------------------------------------------------------
# Разбор сообщения
# ---------------------------------------------------------------------------

def analyze_text(text: str, state: dict[str, Any] | None) -> MessageAnalysis:
    t = text.lower().replace("ё", "е")
    state = state or {}
    req: dict[str, Any] = state.get("requirements", {})
    results: list[dict[str, Any]] = state.get("search_results", [])

    patch: dict[str, Any] = {}
    confidence: dict[str, str] = {}
    interests_add: list[str] = []
    interests_remove: list[str] = []
    cleared: list[str] = []
    contradictions: list[str] = []

    def put(field: str, value: Any, conf: str = "explicit") -> None:
        patch[field] = value
        confidence[field] = conf

    # --- месяц
    for pattern, month in MONTH_PATTERNS:
        if re.search(pattern, t):
            put("month", month)
            break

    # --- длительность: относительная, затем абсолютная
    rel = re.search(_NUM + r"\s+(?:дн\w*|ден\w*)\s+(дольше|больше|длиннее|короче|меньше)", t)
    if rel and req.get("duration_days"):
        delta = _num(rel.group(1)) * (1 if rel.group(2) in ("дольше", "больше", "длиннее") else -1)
        put("duration_days", max(1, req["duration_days"] + delta), "inferred")
    elif "две недели" in t:
        put("duration_days", 14)
    elif re.search(r"недел[юия]", t):
        put("duration_days", 7)
    else:
        m = re.search(_NUM + r"\s*(?:дн\w*|ден\w*|ноч\w*|сут\w*)", t)
        if m:
            put("duration_days", _num(m.group(1)))

    # --- путешественники
    m = re.search(r"(\d+)\s*(?:человек|чел\b|взросл|туриста|путешественник)", t)
    if m:
        put("travelers", int(m.group(1)))
    elif re.search(r"на троих|втроем", t):
        put("travelers", 3)
    elif re.search(r"на четверых|вчетвером", t):
        put("travelers", 4)
    elif re.search(r"на двоих|вдвоем", t):
        put("travelers", 2)
    elif re.search(r"с девушкой|с парнем|с женой|с мужем|с подругой|с другом", t):
        put("travelers", 2, "inferred")
    elif re.search(r"в одиночку|\bсоло\b|\bодин\b|\bодна\b", t):
        put("travelers", 1)

    # --- бюджет
    budget: int | None = None
    m = re.search(r"(\d+(?:[.,]\d+)?)(?:\s*тыс\w*|к\b)", t)
    if m:
        budget = int(float(m.group(1).replace(",", ".")) * 1000)
    elif re.search(r"бюджет|руб|₽|стоимост|дороже|дешевле", t):
        m = re.search(r"(\d{1,3}(?:[  ]\d{3})+|\d{4,})", t)
        if m:
            budget = int(re.sub(r"\D", "", m.group(1)))
    if budget is not None:
        per_person = re.search(r"на (?:человека|чел\b|одного|каждого)", t)
        travelers = patch.get("travelers") or req.get("travelers")
        if per_person and travelers:
            put("budget_total", budget * travelers, "inferred")
        else:
            put("budget_total", budget)
    if re.search(r"бюджет не важен|без ограничени\w* по бюджет|бюджет любой", t):
        cleared.append("budget_total")
        patch.pop("budget_total", None)

    # --- перелёт
    m = re.search(r"(?:не дольше|не более|не больше|максимум|меньше|\bдо\b)\s*(\d+(?:[.,]\d+)?)\s*(?:ч\b|час)", t)
    if m:
        put("max_flight_hours", float(m.group(1).replace(",", ".")))

    # --- погода
    if re.search(r"прохлад|не жарк", t):
        put("weather_preference", "cool")
    elif re.search(r"тепл|жарк|солн|погреться|загар", t):
        put("weather_preference", "warm")

    # --- интересы (с учётом отрицания «без моря»)
    for pattern, tag in INTEREST_PATTERNS:
        m = re.search(pattern, t)
        if not m:
            continue
        before = t[max(0, m.start() - 15): m.start()]
        if re.search(r"\bбез\b|не хоч|не надо|не нужн", before):
            interests_remove.append(tag)
        elif tag not in req.get("interests", []):
            interests_add.append(tag)

    # --- размер отеля
    if re.search(r"не\s+хот\w*[^.]{0,30}огромн|без\s+огромн|небольш\w*\s+отел|маленьк\w*\s+отел|"
                 r"уютн\w*\s+отел|камерн", t):
        put("hotel_size", "small_or_medium", "inferred")
    elif re.search(r"больш\w* отел|крупн\w* отел", t):
        put("hotel_size", "large")

    # --- город вылета
    words = t.split()
    for stem, city in CITY_STEMS:
        if re.search(r"\bиз\s+" + stem, t) or (len(words) <= 3 and stem in t and not req.get("departure_city")):
            put("departure_city", city)
            break

    # --- направление («в Сочи», «на Мальдивы»)
    for entry in DESTINATIONS:
        if any(re.search(r"\b(?:в|во|на)\s+" + alias, t) for alias in entry["aliases"]):
            put("destination", entry["name"])
            break

    # --- противоречия (пример одного правила)
    if re.search(r"дешев|недорог|эконом", t) and re.search(r"люкс|5\s*звезд|пятизвезд", t):
        contradictions.append("просите дёшево, но отель уровня люкс")

    # --- выбор варианта
    selected: str | None = None
    m = re.search(r"(?:вариант|номер|№|опци\w*)\s*(\d+)", t)
    index = int(m.group(1)) if m else None
    if index is None:
        for stem, n in ORDINALS.items():
            if re.search(r"\b" + stem + r"\w*\b(?:\s+вариант)?", t) and re.search(r"бер|выбира|давай|хочу|подход", t):
                index = n
                break
    if index is not None and 1 <= index <= len(results):
        selected = results[index - 1]["id"]
    elif results and re.search(r"бер|выбира|бронир|подходит", t):
        for r in results:
            entry = next((d for d in DESTINATIONS if d["id"] == r["id"]), None)
            if entry and any(alias in t for alias in entry["aliases"]):
                selected = r["id"]
                break

    # --- намерение
    has_changes = bool(patch or interests_add or interests_remove or cleared)
    is_confirm = re.match(r"^\s*(да\b|ага|ок\b|окей|подтвержда|согласн|бронируй|бер[еу]|выбираю|подходит)", t)
    if selected or (is_confirm and not has_changes):
        intent = "confirm"
        # «беру Хургаду» не означает смену направления поиска
        patch.pop("destination", None)
    elif re.search(r"\bкуда\b|посоветуй|идеи", t):
        intent = "inspiration"
    elif re.match(r"^\s*(а\s+)?(почему|зачем|чем|что|как|сколько|какой|какая|где)\b", t) and not has_changes:
        intent = "general_question" if re.search(TRIP_WORDS, t) or results or _mentions_catalog(t) else "other"
        patch.pop("destination", None)
    elif not has_changes:
        intent = "general_question" if (t.strip().endswith("?") and (results or re.search(TRIP_WORDS, t))) \
            else ("search" if re.search(TRIP_WORDS, t) else "other")
    elif any(v is not None for v in req.values() if not isinstance(v, (list, str))) and (
        re.search(r"лучше|давай|а если|измени|поменя|вместо|дольше|короче|увелич|уменьш|теперь", t)
    ):
        intent = "modify_trip"
    else:
        intent = "search"

    return MessageAnalysis(
        intent=intent,  # type: ignore[arg-type]
        patch=TripPatch(**patch),
        interests_add=interests_add,
        interests_remove=interests_remove,
        cleared_fields=cleared,  # type: ignore[arg-type]
        field_confidence=[FieldConfidence(field=f, confidence=c)  # type: ignore[arg-type]
                          for f, c in confidence.items() if f in patch],
        contradictions=contradictions,
        selected_option_id=selected,
    )


def _mentions_catalog(t: str) -> bool:
    return any(alias in t for d in DESTINATIONS for alias in d["aliases"])


# ---------------------------------------------------------------------------
# Сама заглушка
# ---------------------------------------------------------------------------

class OfflineLLM:
    """Реализует интерфейс LLMClient без обращения к сети."""

    def __init__(self) -> None:
        self.calls: list[dict[str, Any]] = []  # журнал вызовов — удобно в тестах
        self._counter = 0

    def parse(self, messages: list[dict[str, Any]], response_model: type[BaseModel]) -> Any:
        self.calls.append({"method": "parse", "messages": messages})
        if response_model is not MessageAnalysis:
            raise LLMError(f"OfflineLLM умеет разбирать только MessageAnalysis, а не {response_model}")
        context = read_context(messages, CONTEXT_MARKER)
        return analyze_text(_last_user_text(messages), context.get("state"))

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | None = None,
    ) -> AssistantTurn:
        self.calls.append({"method": "chat", "messages": messages, "tools": tools})
        context = read_context(messages, CONTEXT_MARKER)
        task = context.get("task")
        state = context.get("state", {})

        # 1. Поиск: если инструменты даны и ещё не вызывались — вызываем.
        if tools and not _tool_answered(messages):
            self._counter += 1
            req = state.get("requirements", {})
            args = {k: req.get(k) for k in (
                "departure_city", "month", "duration_days", "travelers", "interests",
                "budget_total", "max_flight_hours", "weather_preference", "hotel_size", "destination",
            )}
            args["limit"] = 5
            return AssistantTurn(None, [ToolCall(f"call_offline_{self._counter}", "search_destinations",
                                                 json.dumps(args, ensure_ascii=False))])

        # 2. Есть ответ инструмента — пересказываем его.
        tool_payload = _last_tool_payload(messages)
        if tool_payload is not None:
            if "error" in tool_payload:
                return AssistantTurn(f"Поиск не удался: {tool_payload['error']}")
            return AssistantTurn(format_results(tool_payload))

        if task == "search_summary" and context.get("search_payload"):
            return AssistantTurn(format_results(context["search_payload"]))

        if task == "ask":
            return AssistantTurn(question_for(context.get("missing_field", "")))

        if task == "explain":
            return AssistantTurn(_explain(_last_user_text(messages), state))

        return AssistantTurn("Я помогаю планировать поездки. Расскажите, куда и когда хотите поехать?")


def _last_user_text(messages: list[dict[str, Any]]) -> str:
    for message in reversed(messages):
        if message.get("role") == "user":
            return str(message.get("content", ""))
    return ""


def _tool_answered(messages: list[dict[str, Any]]) -> bool:
    """Был ли ответ инструмента ПОСЛЕ последнего сообщения пользователя."""
    for message in reversed(messages):
        if message.get("role") == "tool":
            return True
        if message.get("role") == "user":
            return False
    return False


def _last_tool_payload(messages: list[dict[str, Any]]) -> dict[str, Any] | None:
    for message in reversed(messages):
        if message.get("role") == "tool":
            return json.loads(message["content"])
        if message.get("role") == "user":
            return None
    return None


def _explain(question: str, state: dict[str, Any]) -> str:
    results = state.get("search_results", [])
    if not results:
        return "Пока я не искал варианты — сначала уточню условия поездки."
    q = question.lower().replace("ё", "е")
    prefix = "Внимание: условия изменились после поиска, варианты стоит обновить. " if state.get("results_stale") else ""
    for i, r in enumerate(results, start=1):
        entry = next((d for d in DESTINATIONS if d["id"] == r["id"]), None)
        if entry and any(alias in q for alias in entry["aliases"]):
            return prefix + "Почему этот вариант: " + describe_result(i, r)
    best = results[0]
    return prefix + "Лучший по совокупности вариант — " + describe_result(1, best)
