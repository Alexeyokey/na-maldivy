"""
Детерминированные тексты.

Используются:
  - для критичных шагов (подтверждение и бронь) — их формулирует код,
    чтобы цифры в «чеке» гарантированно совпадали с данными;
  - как запасной ответ, если LLM недоступна;
  - офлайн-заглушкой OfflineLLM.
"""

from __future__ import annotations

from typing import Any

from .schemas import FIELD_LABELS, TripRequirements

MONTH_NAMES = [
    "январь", "февраль", "март", "апрель", "май", "июнь",
    "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь",
]

QUESTION_TEMPLATES: dict[str, str] = {
    "departure_city": "Из какого города планируете вылет?",
    "month": "В каком месяце (или в какие даты) хотите поехать?",
    "duration_days": "На сколько дней планируете поездку?",
    "travelers": "Сколько человек поедет?",
}


def rub(value: int | float) -> str:
    return f"{int(round(value)):,}".replace(",", " ") + " ₽"


def describe_requirements(req: TripRequirements) -> str:
    """Короткое резюме того, что уже известно: «Москва, ноябрь, 7 дн., 2 чел.»."""
    parts: list[str] = []
    if req.destination:
        parts.append(req.destination)
    if req.departure_city:
        parts.append(f"вылет из г. {req.departure_city}")
    if req.month:
        parts.append(MONTH_NAMES[req.month - 1])
    if req.duration_days:
        parts.append(f"{req.duration_days} дн.")
    if req.travelers:
        parts.append(f"{req.travelers} чел.")
    if req.budget_total:
        parts.append(f"бюджет до {rub(req.budget_total)}")
    if req.max_flight_hours:
        parts.append(f"перелёт до {req.max_flight_hours:g} ч")
    if req.interests:
        parts.append("интересы: " + ", ".join(req.interests))
    return ", ".join(parts)


def describe_result(index: int, r: dict[str, Any]) -> str:
    line = (
        f"{index}. {r['name']} ({r['country']}) — ~{rub(r['total_rub'])}, "
        f"перелёт {r['flight_hours']:g} ч, около {r['avg_temp_c']} °C."
    )
    notes: list[str] = []
    if r["fits_budget"]:
        notes.append("укладывается в бюджет")
    else:
        notes.append(f"дороже бюджета на {rub(r['over_budget_rub'])}")
    if r["matched_interests"]:
        notes.append("есть: " + ", ".join(r["matched_interests"]))
    if r["missing_interests"]:
        notes.append("нет: " + ", ".join(r["missing_interests"]))
    return line + " " + "; ".join(notes).capitalize() + "."


def format_results(payload: dict[str, Any]) -> str:
    results = payload.get("results") or []
    if not results:
        return (payload.get("message") or "Ничего не нашлось.") + \
            " Попробуйте ослабить ограничения: бюджет, время перелёта или месяц."
    lines = [payload.get("message", "Вот что нашлось:")]
    lines += [describe_result(i, r) for i, r in enumerate(results, start=1)]
    lines.append("Какой вариант нравится? Можно выбрать номер или изменить условия.")
    return "\n".join(lines)


def format_confirmation(option: dict[str, Any], req: TripRequirements) -> str:
    # Превышение бюджета показываем явно: пользователь подтверждает,
    # зная об этом, а не узнаёт после «покупки».
    warning = ""
    if not option["fits_budget"]:
        warning = f"Внимание: это на {rub(option['over_budget_rub'])} дороже вашего бюджета.\n"
    return (
        f"Вы выбрали: {option['name']} ({option['country']}).\n"
        f"Состав поездки: {describe_requirements(req)}.\n"
        f"Оценка стоимости: {rub(option['total_rub'])} "
        f"(перелёт {rub(option['flight_cost_rub'])} + проживание и питание {rub(option['stay_cost_rub'])}).\n"
        f"{warning}"
        "Это демо-бронирование (имитация, деньги не списываются). Подтверждаете? (да / нет)"
    )


def format_which_option(results: list[dict[str, Any]]) -> str:
    names = ", ".join(f"{i}. {r['name']}" for i, r in enumerate(results, start=1))
    return f"Уточните, какой вариант выбираете: {names}?"


def question_for(field: str) -> str:
    return QUESTION_TEMPLATES.get(field, f"Уточните, пожалуйста: {FIELD_LABELS.get(field, field)}?")
